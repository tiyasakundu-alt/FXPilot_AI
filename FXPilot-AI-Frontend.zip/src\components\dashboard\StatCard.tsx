import React from 'react';
import { LucideIcon, TrendingUp, TrendingDown, HelpCircle } from 'lucide-react';

interface StatCardProps {
  title: string;
  value: string;
  change?: string;
  isPositiveChange?: boolean;
  changeLabel?: string;
  icon: LucideIcon;
  subtitle?: string;
  tooltip?: string;
}

export const StatCard: React.FC<StatCardProps> = ({
  title,
  value,
  change,
  isPositiveChange = true,
  changeLabel = 'vs last month',
  icon: Icon,
  subtitle,
  tooltip,
}) => {
  return (
    <div className="relative p-5 rounded-xl border border-fx-border bg-fx-card hover:border-teal-500/30 transition-all duration-200 shadow-subtle group">
      {/* Top row */}
      <div className="flex items-center justify-between">
        <div className="flex items-center space-x-1.5">
          <span className="text-xs font-medium text-fx-muted uppercase tracking-wider">{title}</span>
          {tooltip && (
            <div className="relative group/tip cursor-help">
              <HelpCircle className="w-3.5 h-3.5 text-fx-muted/70 hover:text-fx-muted" />
              <div className="absolute left-1/2 -translate-x-1/2 bottom-full mb-1.5 hidden group-hover/tip:block w-48 p-2 rounded bg-fx-elevated text-[11px] text-fx-text border border-fx-border shadow-elevated z-20 pointer-events-none">
                {tooltip}
              </div>
            </div>
          )}
        </div>
        <div className="p-2 rounded-lg bg-fx-elevated border border-fx-border group-hover:border-teal-500/30 text-fx-teal transition-colors">
          <Icon className="w-4 h-4" />
        </div>
      </div>

      {/* Main value */}
      <div className="mt-3 flex items-baseline justify-between">
        <h3 className="text-2xl font-bold tracking-tight text-fx-text">{value}</h3>
      </div>

      {/* Footer / Change indicators */}
      <div className="mt-3 flex items-center justify-between text-xs pt-2.5 border-t border-fx-border/50">
        {change ? (
          <div className="flex items-center space-x-1.5">
            <span
              className={`inline-flex items-center font-semibold font-mono text-[11px] ${
                isPositiveChange ? 'text-fx-green' : 'text-fx-red'
              }`}
            >
              {isPositiveChange ? (
                <TrendingUp className="w-3 h-3 mr-0.5 inline" />
              ) : (
                <TrendingDown className="w-3 h-3 mr-0.5 inline" />
              )}
              {change}
            </span>
            <span className="text-fx-muted text-[11px]">{changeLabel}</span>
          </div>
        ) : subtitle ? (
          <span className="text-fx-muted text-[11px] leading-relaxed">{subtitle}</span>
        ) : (
          <span className="text-fx-muted text-[11px]">Real-time audit</span>
        )}
      </div>
    </div>
  );
};
