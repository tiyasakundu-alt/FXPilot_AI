import React from 'react';
import { Bot, ArrowRight, Sparkles, TrendingUp, ShieldCheck, Zap } from 'lucide-react';
import { Link } from 'react-router-dom';

export const AIInsight: React.FC = () => {
  return (
    <div className="p-5 rounded-xl border border-teal-500/30 bg-gradient-to-br from-fx-card via-fx-card to-teal-950/20 shadow-subtle flex flex-col justify-between relative overflow-hidden">
      {/* Background glow element */}
      <div className="absolute top-0 right-0 w-36 h-36 bg-teal-500/10 rounded-full blur-2xl pointer-events-none" />

      {/* Header */}
      <div>
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <div className="w-7 h-7 rounded-lg bg-teal-500/15 border border-teal-500/30 flex items-center justify-center text-fx-teal">
              <Bot className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-xs font-semibold text-fx-text uppercase tracking-wider">
                FXPilot AI Tactical Signal
              </h3>
              <span className="text-[10px] text-fx-muted">USD/INR Engine v1.0 • Simulated</span>
            </div>
          </div>

          <span className="inline-flex items-center space-x-1 px-2 py-0.5 rounded-full bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 text-[10px] font-mono">
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
            <span>Optimal Window</span>
          </span>
        </div>

        {/* Tactical Recommendation Text */}
        <div className="mt-4 p-3.5 rounded-lg border border-fx-border bg-fx-elevated/60 text-xs">
          <p className="text-fx-text font-medium leading-relaxed">
            USD/INR is hovering near a 30-day high resistance level (<strong>86.48</strong>). Historical spread models indicate PayPal weekend margins widen by an extra <span className="text-rose-400 font-mono font-semibold">+0.45%</span>.
          </p>
          <div className="mt-2.5 flex items-center space-x-2 text-[11px] text-fx-teal font-medium">
            <Zap className="w-3.5 h-3.5 shrink-0" />
            <span>Execute weekday morning batches to capture ~₹24,850 in illustrative savings.</span>
          </div>
        </div>

        {/* Quantitative Metrics Bar */}
        <div className="grid grid-cols-3 gap-2 mt-3 text-center">
          <div className="p-2 rounded bg-fx-elevated/30 border border-fx-border/50">
            <span className="text-[10px] text-fx-muted block">Signal Confidence</span>
            <span className="text-xs font-bold font-mono text-fx-teal">94%</span>
          </div>
          <div className="p-2 rounded bg-fx-elevated/30 border border-fx-border/50">
            <span className="text-[10px] text-fx-muted block">Spread Risk</span>
            <span className="text-xs font-bold font-mono text-emerald-400">Low (0.28%)</span>
          </div>
          <div className="p-2 rounded bg-fx-elevated/30 border border-fx-border/50">
            <span className="text-[10px] text-fx-muted block">Est. Alpha</span>
            <span className="text-xs font-bold font-mono text-fx-text">+1.85%</span>
          </div>
        </div>
      </div>

      {/* Call to action */}
      <div className="mt-4 pt-3 border-t border-fx-border/60 flex items-center justify-between">
        <span className="text-[11px] text-fx-muted">
          Ask conversational queries about any currency corridor
        </span>
        <Link
          to="/agent"
          className="inline-flex items-center space-x-1.5 px-3 py-1.5 rounded-lg bg-teal-500/15 hover:bg-teal-500/25 border border-teal-500/30 text-fx-teal text-xs font-medium transition-colors"
        >
          <span>Open AI Agent</span>
          <ArrowRight className="w-3.5 h-3.5" />
        </Link>
      </div>
    </div>
  );
};
