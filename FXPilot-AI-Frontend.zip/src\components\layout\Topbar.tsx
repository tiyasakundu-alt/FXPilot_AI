import React, { useState } from 'react';
import { useLocation } from 'react-router-dom';
import { Menu, Search, Bell, Check, ExternalLink, ShieldCheck } from 'lucide-react';
import { ThemeToggle } from '../common/ThemeToggle';
import { DemoBanner } from '../common/DemoBanner';
import { SearchModal } from '../common/SearchModal';
import { useToast } from '../../context/ToastContext';

interface TopbarProps {
  onOpenMobile: () => void;
}

export const Topbar: React.FC<TopbarProps> = ({ onOpenMobile }) => {
  const location = useLocation();
  const { addToast } = useToast();
  const [isSearchOpen, setIsSearchOpen] = useState(false);
  const [showNotifications, setShowNotifications] = useState(false);
  const [notifications, setNotifications] = useState([
    {
      id: 1,
      title: 'High Markup Warning',
      desc: 'EUR/INR conversion had 3.25% markup ($403 lost to spread).',
      time: '12m ago',
      read: false,
    },
    {
      id: 2,
      title: 'Spread Widening Detected',
      desc: 'USD/INR weekend spread expanded +0.45% above normal.',
      time: '1h ago',
      read: false,
    },
    {
      id: 3,
      title: 'Batch Optimization Success',
      desc: 'Saved ₹12,400 by executing scheduled settlement on USD.',
      time: '1d ago',
      read: true,
    },
  ]);

  const unreadCount = notifications.filter((n) => !n.read).length;

  const markAllRead = () => {
    setNotifications((prev) => prev.map((n) => ({ ...n, read: true })));
    addToast({
      type: 'info',
      title: 'Notifications Cleared',
      message: 'All notifications marked as read.',
    });
  };

  // Compute page title from path
  const getPageInfo = () => {
    switch (location.pathname) {
      case '/':
        return { title: 'Overview Dashboard', subtitle: 'Institutional FX monitoring & spread auditing' };
      case '/converter':
        return { title: 'FX Converter', subtitle: 'Calculate real-time spreads & estimate provider costs' };
      case '/analytics':
        return { title: 'FX Analytics', subtitle: 'Historical volatility & margin leakage analysis' };
      case '/agent':
        return { title: 'AI Intelligence Agent', subtitle: 'Cross-border rate copilot & strategy assistant' };
      case '/transactions':
        return { title: 'Transactions Audit', subtitle: 'Audited historical payouts & fee breakdowns' };
      case '/settings':
        return { title: 'Settings', subtitle: 'Platform preferences, theme & FastAPI integration' };
      default:
        return { title: 'FXPilot AI', subtitle: 'Cross-border FX Intelligence' };
    }
  };

  const pageInfo = getPageInfo();

  return (
    <>
      <header className="sticky top-0 z-30 h-16 border-b border-fx-border bg-fx-sidebar/80 backdrop-blur-md px-4 sm:px-6 flex items-center justify-between">
        {/* Left Side: Mobile Menu + Page Titles */}
        <div className="flex items-center space-x-3">
          <button
            onClick={onOpenMobile}
            className="p-2 -ml-2 text-fx-muted hover:text-fx-text rounded-lg lg:hidden"
            aria-label="Open sidebar"
          >
            <Menu className="w-5 h-5" />
          </button>

          <div>
            <div className="flex items-center space-x-2.5">
              <h1 className="text-sm sm:text-base font-semibold tracking-tight text-fx-text">
                {pageInfo.title}
              </h1>
              <DemoBanner variant="badge" />
            </div>
            <p className="hidden md:block text-[11px] text-fx-muted">
              {pageInfo.subtitle}
            </p>
          </div>
        </div>

        {/* Right Side: Search, Demo Indicator, Notifications, Theme, Profile */}
        <div className="flex items-center space-x-2 sm:space-x-3">
          {/* Search Trigger */}
          <button
            onClick={() => setIsSearchOpen(true)}
            className="flex items-center space-x-2 px-3 py-1.5 rounded-lg border border-fx-border bg-fx-card hover:bg-fx-elevated text-fx-muted text-xs transition-colors"
            title="Search (Ctrl + K)"
          >
            <Search className="w-3.5 h-3.5 text-fx-teal" />
            <span className="hidden sm:inline">Search...</span>
            <kbd className="hidden sm:inline-block text-[10px] font-mono px-1.5 py-0.2 rounded bg-fx-elevated border border-fx-border">
              ⌘K
            </kbd>
          </button>

          {/* Notifications Dropdown */}
          <div className="relative">
            <button
              onClick={() => setShowNotifications(!showNotifications)}
              className="relative p-2 rounded-lg border border-fx-border bg-fx-card hover:bg-fx-elevated text-fx-muted hover:text-fx-text transition-colors"
              aria-label="View notifications"
            >
              <Bell className="w-4 h-4" />
              {unreadCount > 0 && (
                <span className="absolute top-1.5 right-1.5 w-2 h-2 rounded-full bg-rose-500 animate-pulse" />
              )}
            </button>

            {showNotifications && (
              <div
                className="absolute right-0 mt-2 w-80 sm:w-88 rounded-xl border border-fx-border bg-fx-card shadow-2xl p-3 z-50 animate-fadeIn"
                onClick={(e) => e.stopPropagation()}
              >
                <div className="flex items-center justify-between pb-2 border-b border-fx-border">
                  <div className="flex items-center space-x-2">
                    <span className="text-xs font-semibold text-fx-text">Notifications</span>
                    {unreadCount > 0 && (
                      <span className="text-[10px] px-1.5 py-0.2 rounded-full bg-rose-500/10 text-rose-400 font-mono">
                        {unreadCount} new
                      </span>
                    )}
                  </div>
                  {unreadCount > 0 && (
                    <button
                      onClick={markAllRead}
                      className="text-[11px] text-fx-teal hover:underline flex items-center space-x-1"
                    >
                      <Check className="w-3 h-3" />
                      <span>Mark all read</span>
                    </button>
                  )}
                </div>

                <div className="divide-y divide-fx-border/60 max-h-72 overflow-y-auto my-1">
                  {notifications.map((n) => (
                    <div
                      key={n.id}
                      className={`py-2.5 px-1.5 text-xs transition-colors rounded ${
                        !n.read ? 'bg-teal-500/5' : ''
                      }`}
                    >
                      <div className="flex items-center justify-between">
                        <span className="font-semibold text-fx-text">{n.title}</span>
                        <span className="text-[10px] text-fx-muted font-mono">{n.time}</span>
                      </div>
                      <p className="text-[11px] text-fx-muted mt-0.5 leading-relaxed">{n.desc}</p>
                    </div>
                  ))}
                </div>

                <div className="pt-2 border-t border-fx-border text-center">
                  <span className="text-[10px] text-fx-muted">Simulated Real-time Alert Dispatcher</span>
                </div>
              </div>
            )}
          </div>

          {/* Theme Toggle */}
          <ThemeToggle />

          {/* User Profile Avatar */}
          <div className="flex items-center pl-1 sm:pl-2 border-l border-fx-border space-x-2.5">
            <div className="w-8 h-8 rounded-full bg-teal-500/15 border border-teal-500/30 flex items-center justify-center text-fx-teal font-semibold text-xs">
              AG
            </div>
            <div className="hidden xl:flex flex-col text-left">
              <span className="text-xs font-medium text-fx-text truncate">Apex Global</span>
              <span className="text-[10px] text-fx-muted truncate">Merchant Pro</span>
            </div>
          </div>
        </div>
      </header>

      {/* Global Search Modal */}
      <SearchModal isOpen={isSearchOpen} onClose={() => setIsSearchOpen(false)} />
    </>
  );
};
