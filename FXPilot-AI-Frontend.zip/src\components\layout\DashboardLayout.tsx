import React, { useState } from 'react';
import { Outlet } from 'react-router-dom';
import { Sidebar } from './Sidebar';
import { Topbar } from './Topbar';

export const DashboardLayout: React.FC = () => {
  const [collapsed, setCollapsed] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);

  return (
    <div className="min-h-screen bg-fx-bg text-fx-text flex flex-col">
      {/* Sidebar */}
      <Sidebar
        collapsed={collapsed}
        onToggleCollapse={() => setCollapsed(!collapsed)}
        mobileOpen={mobileOpen}
        onCloseMobile={() => setMobileOpen(false)}
      />

      {/* Main Content Area */}
      <div
        className={`flex-1 flex flex-col transition-all duration-300 ease-in-out ${
          collapsed ? 'lg:pl-20' : 'lg:pl-64'
        }`}
      >
        <Topbar onOpenMobile={() => setMobileOpen(true)} />

        <main className="flex-1 p-4 sm:p-6 lg:p-8 max-w-7xl w-full mx-auto animate-fadeIn">
          <Outlet />
        </main>

        {/* Global Footer */}
        <footer className="border-t border-fx-border py-4 px-6 text-center text-xs text-fx-muted flex flex-col sm:flex-row items-center justify-between space-y-2 sm:space-y-0">
          <div className="flex items-center space-x-2">
            <span className="font-semibold text-fx-text">FXPilot AI</span>
            <span>— Institutional Cross-Border FX Intelligence</span>
          </div>
          <div className="flex items-center space-x-4 text-[11px]">
            <span>FastAPI Backend Ready</span>
            <span className="inline-block w-1.5 h-1.5 rounded-full bg-fx-teal" />
            <span>Simulated Benchmark Models</span>
          </div>
        </footer>
      </div>
    </div>
  );
};
