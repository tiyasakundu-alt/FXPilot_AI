/**
 * FXPilot Service Layer
 * 
 * Provides unified access to FX conversion, rate history, transaction audits,
 * and AI agent intelligence.
 * 
 * BACKEND INTEGRATION NOTE:
 * When connecting to your Python FastAPI backend, update `API_CONFIG.useMock`
 * to false and specify `VITE_FASTAPI_BASE_URL` in your `.env` file.
 */

import { CurrencyCode, FXQuote, RateHistoryPoint, TimePeriod, Transaction, ChatMessage } from '../types';
import {
  MOCK_TRANSACTIONS,
  calculateQuote,
  generateRateHistory,
  getMidMarketRate,
  getProviderRate,
  getSimulatedAIResponse,
} from '../data/mockData';

export const API_CONFIG = {
  baseUrl: (import.meta as any).env?.VITE_FASTAPI_BASE_URL || 'http://localhost:8000/api/v1',
  useMock: true, // Switch to false when FastAPI is running
  timeoutMs: 8000,
};

export class FXService {
  /**
   * Fetches real-time rate comparison and conversion calculation
   */
  static async getConversionQuote(
    from: CurrencyCode,
    to: CurrencyCode,
    amount: number
  ): Promise<FXQuote> {
    if (API_CONFIG.useMock) {
      // Realistic simulated network latency (100ms)
      await new Promise((resolve) => setTimeout(resolve, 80));
      return calculateQuote(from, to, amount);
    }

    const response = await fetch(`${API_CONFIG.baseUrl}/quotes/calculate`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ from_currency: from, to_currency: to, amount }),
    });

    if (!response.ok) {
      throw new Error(`Failed to fetch quote from backend: ${response.statusText}`);
    }

    return response.json();
  }

  /**
   * Fetches historical exchange rates and provider spread bands
   */
  static async getRateHistory(period: TimePeriod, pair: string = 'USD/INR'): Promise<RateHistoryPoint[]> {
    if (API_CONFIG.useMock) {
      return generateRateHistory(period, pair);
    }

    const response = await fetch(`${API_CONFIG.baseUrl}/rates/history?pair=${pair}&period=${period}`);
    if (!response.ok) {
      throw new Error(`Failed to fetch history from backend: ${response.statusText}`);
    }

    return response.json();
  }

  /**
   * Fetches transaction history with optional filtering
   */
  static async getTransactions(filters?: {
    search?: string;
    currencyPair?: string;
    status?: string;
  }): Promise<Transaction[]> {
    if (API_CONFIG.useMock) {
      let results = [...MOCK_TRANSACTIONS];

      if (filters?.search) {
        const query = filters.search.toLowerCase();
        results = results.filter(
          (t) =>
            t.id.toLowerCase().includes(query) ||
            t.merchantName.toLowerCase().includes(query) ||
            t.referenceId.toLowerCase().includes(query)
        );
      }

      if (filters?.currencyPair && filters.currencyPair !== 'ALL') {
        results = results.filter((t) => t.currencyPair === filters.currencyPair);
      }

      if (filters?.status && filters.status !== 'ALL') {
        results = results.filter((t) => t.status === filters.status);
      }

      return results;
    }

    const params = new URLSearchParams(filters as any).toString();
    const response = await fetch(`${API_CONFIG.baseUrl}/transactions?${params}`);
    return response.json();
  }

  /**
   * Sends user message to FXPilot AI Agent and receives structured intelligence
   */
  static async sendAIMessage(userQuery: string): Promise<ChatMessage> {
    if (API_CONFIG.useMock) {
      // Simulate realistic AI thought generation time (400ms)
      await new Promise((resolve) => setTimeout(resolve, 400));
      return getSimulatedAIResponse(userQuery);
    }

    const response = await fetch(`${API_CONFIG.baseUrl}/agent/chat`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ query: userQuery }),
    });

    return response.json();
  }

  /**
   * Current live ticker rates
   */
  static getLiveTicker(from: CurrencyCode, to: CurrencyCode) {
    const mid = getMidMarketRate(from, to);
    const provider = getProviderRate(from, to);
    const markupPct = ((mid - provider) / mid) * 100;
    return {
      midMarket: Number(mid.toFixed(4)),
      provider: Number(provider.toFixed(4)),
      markupPct: Number(markupPct.toFixed(2)),
      spread: Number((mid - provider).toFixed(4)),
    };
  }
}
