import React, { useState, useRef, useEffect } from 'react';
import { ChatMessage } from '../types';
import { INITIAL_CHAT_MESSAGES, getSimulatedAIResponse, calculateQuote } from '../data/mockData';
import { DemoBanner } from '../components/common/DemoBanner';
import { formatCurrency, formatPercent } from '../utils/formatters';
import {
  Bot,
  Send,
  User,
  Sparkles,
  ArrowRight,
  TrendingUp,
  AlertCircle,
  HelpCircle,
  RefreshCw,
  Clock,
  Compass,
  CheckCircle2,
} from 'lucide-react';
import { useToast } from '../context/ToastContext';

export const Agent: React.FC = () => {
  const { addToast } = useToast();
  const [messages, setMessages] = useState<ChatMessage[]>(INITIAL_CHAT_MESSAGES);
  const [inputValue, setInputValue] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const suggestedPrompts = [
    'Analyse my $5,000 USD to INR conversion.',
    'Compare the current reference and provider rates.',
    'Explain how much markup I am paying.',
    'Should I convert now or wait?',
  ];

  // Auto-scroll chat to bottom
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, isTyping]);

  const handleSendMessage = (textToSend?: string) => {
    const text = textToSend || inputValue;
    if (!text.trim() || isTyping) return;

    const userMessage: ChatMessage = {
      id: `user-${Date.now()}`,
      sender: 'user',
      content: text,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    };

    setMessages((prev) => [...prev, userMessage]);
    if (!textToSend) setInputValue('');
    setIsTyping(true);

    // Simulate realistic AI thought process & response generation
    setTimeout(() => {
      const aiReply = getSimulatedAIResponse(text);
      setMessages((prev) => [...prev, aiReply]);
      setIsTyping(false);
    }, 600);
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  };

  const handleResetChat = () => {
    setMessages(INITIAL_CHAT_MESSAGES);
    addToast({
      type: 'info',
      title: 'Chat Reset',
      message: 'Conversational memory refreshed.',
    });
  };

  // Derive active analysis panel data from latest message with analysis, or default USD/INR
  const latestAnalysisMessage = [...messages].reverse().find((m) => m.analysis);
  const activeAnalysis = latestAnalysisMessage?.analysis || {
    pair: 'USD/INR',
    amount: 5000,
    referenceRate: 86.4250,
    providerRate: 83.6162,
    markupPercent: 3.25,
    markupLoss: 162.50,
    recommendation: 'HOLD / WAIT' as const,
    confidence: 94,
    rationale: 'USD/INR testing 30-day resistance. Recommend morning conversion window.',
  };

  return (
    <div className="space-y-6">
      <DemoBanner variant="banner" />

      {/* Page Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center space-x-2">
            <h1 className="text-xl sm:text-2xl font-bold tracking-tight text-fx-text">
              Meet your FX intelligence agent.
            </h1>
            <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-teal-500/10 text-fx-teal border border-teal-500/20">
              Autonomous Copilot
            </span>
          </div>
          <p className="text-xs sm:text-sm text-fx-muted mt-1">
            Simulated conversational agent powered by cross-border FX pattern recognition and real-time spread analytics.
          </p>
        </div>

        <button
          onClick={handleResetChat}
          className="self-start sm:self-auto inline-flex items-center space-x-1.5 px-3 py-1.5 rounded-lg border border-fx-border bg-fx-card hover:bg-fx-elevated text-fx-muted hover:text-fx-text text-xs transition-colors"
        >
          <RefreshCw className="w-3.5 h-3.5" />
          <span>Clear History</span>
        </button>
      </div>

      {/* Main Two-Column Layout */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* Left Column: Chat Conversation Window (Takes 8 cols) */}
        <div className="lg:col-span-8 flex flex-col h-[650px] rounded-2xl border border-fx-border bg-fx-card shadow-elevated overflow-hidden">
          {/* Chat Header Bar */}
          <div className="px-5 py-3.5 border-b border-fx-border bg-fx-elevated/40 flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <div className="w-8 h-8 rounded-lg bg-teal-500/15 border border-teal-500/30 flex items-center justify-center text-fx-teal">
                <Bot className="w-4 h-4" />
              </div>
              <div>
                <h3 className="text-xs font-semibold text-fx-text">FXPilot Copilot v1.0</h3>
                <div className="flex items-center space-x-1.5 text-[10px] text-emerald-400 font-mono">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
                  <span>Online • Simulated Context Connected</span>
                </div>
              </div>
            </div>

            <span className="text-[11px] font-mono text-fx-muted hidden sm:inline">
              FastAPI Endpoint Ready: /api/v1/agent/chat
            </span>
          </div>

          {/* Messages Scroll Area */}
          <div className="flex-1 overflow-y-auto p-5 space-y-4">
            {messages.map((msg) => (
              <div
                key={msg.id}
                className={`flex space-x-3 ${msg.sender === 'user' ? 'justify-end' : 'justify-start'}`}
              >
                {msg.sender === 'assistant' && (
                  <div className="w-7 h-7 rounded-lg bg-teal-500/10 border border-teal-500/20 flex items-center justify-center text-fx-teal shrink-0 mt-0.5">
                    <Bot className="w-4 h-4" />
                  </div>
                )}

                <div
                  className={`max-w-[85%] sm:max-w-[75%] rounded-2xl p-4 text-xs leading-relaxed ${
                    msg.sender === 'user'
                      ? 'bg-fx-teal text-black font-medium rounded-tr-none'
                      : 'bg-fx-elevated border border-fx-border text-fx-text rounded-tl-none space-y-2'
                  }`}
                >
                  {/* Message content rendering */}
                  <div className="prose prose-invert prose-xs max-w-none">
                    {msg.content.split('\n\n').map((paragraph, idx) => (
                      <p key={idx} className="whitespace-pre-line my-1">
                        {paragraph}
                      </p>
                    ))}
                  </div>

                  <div
                    className={`text-[10px] font-mono mt-1 ${
                      msg.sender === 'user' ? 'text-black/60 text-right' : 'text-fx-muted'
                    }`}
                  >
                    {msg.timestamp} {msg.sender === 'assistant' && '• Simulated Model'}
                  </div>
                </div>

                {msg.sender === 'user' && (
                  <div className="w-7 h-7 rounded-lg bg-fx-elevated border border-fx-border flex items-center justify-center text-fx-muted shrink-0 mt-0.5">
                    <User className="w-4 h-4" />
                  </div>
                )}
              </div>
            ))}

            {/* Typing Indicator */}
            {isTyping && (
              <div className="flex items-center space-x-3">
                <div className="w-7 h-7 rounded-lg bg-teal-500/10 border border-teal-500/20 flex items-center justify-center text-fx-teal shrink-0">
                  <Bot className="w-4 h-4" />
                </div>
                <div className="px-4 py-3 rounded-2xl bg-fx-elevated border border-fx-border text-xs flex items-center space-x-1.5 text-fx-muted">
                  <span className="w-1.5 h-1.5 rounded-full bg-fx-teal animate-bounce" />
                  <span className="w-1.5 h-1.5 rounded-full bg-fx-teal animate-bounce [animation-delay:0.2s]" />
                  <span className="w-1.5 h-1.5 rounded-full bg-fx-teal animate-bounce [animation-delay:0.4s]" />
                  <span className="ml-2 font-mono text-[11px]">Analyzing spread feeds...</span>
                </div>
              </div>
            )}

            <div ref={messagesEndRef} />
          </div>

          {/* Suggested Prompts Pills */}
          <div className="px-4 py-2.5 border-t border-fx-border/60 bg-fx-elevated/20 overflow-x-auto flex items-center space-x-2">
            <span className="text-[11px] font-mono uppercase tracking-wider text-fx-muted shrink-0">
              Prompts:
            </span>
            {suggestedPrompts.map((prompt, i) => (
              <button
                key={i}
                onClick={() => handleSendMessage(prompt)}
                disabled={isTyping}
                className="px-2.5 py-1 rounded-full border border-fx-border bg-fx-card hover:bg-fx-elevated hover:border-teal-500/30 text-fx-muted hover:text-fx-text text-[11px] whitespace-nowrap transition-colors shrink-0 disabled:opacity-50"
              >
                {prompt}
              </button>
            ))}
          </div>

          {/* Input Box Footer */}
          <div className="p-3.5 border-t border-fx-border bg-fx-card flex items-center space-x-3">
            <input
              type="text"
              value={inputValue}
              onChange={(e) => setInputValue(e.target.value)}
              onKeyDown={handleKeyDown}
              disabled={isTyping}
              placeholder="Ask FXPilot about conversions, PayPal markups, or execution timing..."
              className="flex-1 bg-fx-elevated text-fx-text text-xs placeholder:text-fx-muted border border-fx-border rounded-xl px-4 py-2.5 focus:outline-none focus:border-fx-teal focus:ring-1 focus:ring-fx-teal transition-colors"
            />
            <button
              onClick={() => handleSendMessage()}
              disabled={!inputValue.trim() || isTyping}
              className="p-2.5 rounded-xl bg-fx-teal text-black hover:opacity-90 disabled:opacity-40 transition-opacity shrink-0"
              aria-label="Send message"
            >
              <Send className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Right Column: Dynamic Live Analysis Panel (Takes 4 cols) */}
        <div className="lg:col-span-4 space-y-4">
          <div className="p-5 rounded-2xl border border-teal-500/30 bg-fx-card shadow-elevated space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-fx-border/60">
              <div>
                <span className="text-[10px] font-mono uppercase tracking-wider text-fx-muted">
                  Tactical Intelligence Panel
                </span>
                <h3 className="text-sm font-semibold text-fx-text">
                  {activeAnalysis.pair} Live Audit
                </h3>
              </div>
              <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
                Confidence: {activeAnalysis.confidence}%
              </span>
            </div>

            {/* Analysis Metric 1: Current Reference Rate */}
            <div className="p-3 rounded-lg border border-fx-border bg-fx-elevated/40">
              <span className="text-[11px] text-fx-muted block">Current Reference Rate</span>
              <div className="text-lg font-bold font-mono text-fx-teal mt-0.5">
                {activeAnalysis.referenceRate.toFixed(4)}
              </div>
              <span className="text-[10px] text-fx-muted">Mid-market interbank zero-markup</span>
            </div>

            {/* Analysis Metric 2: Provider Quoted Rate */}
            <div className="p-3 rounded-lg border border-fx-border bg-fx-elevated/40">
              <span className="text-[11px] text-fx-muted block">Provider Quoted Rate</span>
              <div className="text-lg font-bold font-mono text-fx-text mt-0.5">
                {activeAnalysis.providerRate.toFixed(4)}
              </div>
              <span className="text-[10px] text-rose-400">
                Simulated PayPal retail conversion quote
              </span>
            </div>

            {/* Analysis Metric 3: Conversion Markup */}
            <div className="p-3 rounded-lg border border-rose-500/20 bg-rose-500/5">
              <div className="flex items-center justify-between">
                <span className="text-[11px] text-rose-400 font-medium">Conversion Markup</span>
                <span className="text-sm font-bold font-mono text-rose-400">
                  +{activeAnalysis.markupPercent}%
                </span>
              </div>
              <p className="text-[11px] text-fx-muted mt-1">
                Estimated loss: -${activeAnalysis.markupLoss.toFixed(2)} USD per $5k batch.
              </p>
            </div>

            {/* Analysis Metric 4: AI Recommendation */}
            <div className="p-3.5 rounded-lg border border-teal-500/30 bg-teal-500/10 space-y-1.5">
              <span className="text-[10px] font-mono uppercase tracking-wider text-fx-teal font-semibold">
                Strategic Recommendation
              </span>
              <div className="text-sm font-bold text-fx-text">
                {activeAnalysis.recommendation}
              </div>
              <p className="text-xs text-fx-muted leading-relaxed">
                {activeAnalysis.rationale}
              </p>
            </div>

            <div className="pt-2 text-[10px] text-fx-muted leading-relaxed border-t border-fx-border/50">
              <strong>Disclaimer:</strong> Responses and tactical signals are generated via simulation rules until the production FastAPI agent backend is attached.
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
