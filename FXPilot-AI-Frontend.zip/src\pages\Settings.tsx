import React, { useState } from 'react';
import { useTheme } from '../context/ThemeContext';
import { CurrencyCode } from '../types';
import { SUPPORTED_CURRENCIES } from '../data/mockData';
import { DemoBanner } from '../components/common/DemoBanner';
import {
  Sun,
  Moon,
  Bell,
  Globe,
  User,
  Shield,
  Key,
  Save,
  CheckCircle2,
  Copy,
  Server,
  Code2,
  HelpCircle,
  ExternalLink,
} from 'lucide-react';
import { useToast } from '../context/ToastContext';

export const Settings: React.FC = () => {
  const { theme, setTheme } = useTheme();
  const { addToast } = useToast();

  // Settings State
  const [baseCurrency, setBaseCurrency] = useState<CurrencyCode>('USD');
  const [targetCurrency, setTargetCurrency] = useState<CurrencyCode>('INR');
  const [alertThreshold, setAlertThreshold] = useState<number>(2.5);
  const [emailAlerts, setEmailAlerts] = useState<boolean>(true);
  const [spikeAlerts, setSpikeAlerts] = useState<boolean>(true);
  const [dailyDigest, setDailyDigest] = useState<boolean>(false);
  const [merchantName, setMerchantName] = useState<string>('Apex Global Merchandising Ltd');
  const [businessEntity, setBusinessEntity] = useState<string>('US Delaware C-Corp');
  const [fastApiUrl, setFastApiUrl] = useState<string>('http://localhost:8000/api/v1');
  const [mockApiKey] = useState<string>('fxp_live_9a7bc24f8d910e11832fa64389');
  const [isTestingConnection, setIsTestingConnection] = useState<boolean>(false);

  const handleSaveSettings = () => {
    addToast({
      type: 'success',
      title: 'Settings Saved',
      message: 'Your platform preferences and thresholds have been updated.',
    });
  };

  const handleCopyApiKey = () => {
    navigator.clipboard.writeText(mockApiKey);
    addToast({
      type: 'info',
      title: 'API Key Copied',
      message: 'Simulated API bearer token copied to clipboard.',
    });
  };

  const handleTestFastAPI = () => {
    setIsTestingConnection(true);
    setTimeout(() => {
      setIsTestingConnection(false);
      addToast({
        type: 'info',
        title: 'Backend Endpoint Verified',
        message: `Validated connection structure for ${fastApiUrl} (Ready for FastAPI launch).`,
      });
    }, 700);
  };

  return (
    <div className="space-y-6 max-w-4xl mx-auto">
      <DemoBanner variant="banner" />

      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl sm:text-2xl font-bold tracking-tight text-fx-text">
            Settings & Integrations
          </h1>
          <p className="text-xs sm:text-sm text-fx-muted mt-0.5">
            Configure appearance, alert thresholds, profile details, and FastAPI connection endpoints.
          </p>
        </div>

        <button
          onClick={handleSaveSettings}
          className="self-start sm:self-auto inline-flex items-center space-x-2 px-4 py-2 rounded-xl bg-fx-teal text-black text-xs font-semibold hover:opacity-90 transition-opacity shadow-sm"
        >
          <Save className="w-3.5 h-3.5" />
          <span>Save Changes</span>
        </button>
      </div>

      {/* Section 1: Appearance Settings */}
      <div className="p-6 rounded-2xl border border-fx-border bg-fx-card shadow-subtle space-y-4">
        <div className="flex items-center justify-between pb-3 border-b border-fx-border/60">
          <div>
            <h3 className="text-sm font-semibold text-fx-text">Appearance & Visual Theme</h3>
            <p className="text-xs text-fx-muted mt-0.5">
              Select institutional dark mode or clean high-contrast light theme
            </p>
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          {/* Dark Mode Card */}
          <button
            onClick={() => setTheme('dark')}
            className={`p-4 rounded-xl border text-left transition-all flex items-start space-x-3.5 ${
              theme === 'dark'
                ? 'border-fx-teal bg-teal-500/10 shadow-glow-teal'
                : 'border-fx-border bg-fx-elevated/40 hover:bg-fx-elevated'
            }`}
          >
            <div className="p-2.5 rounded-lg bg-black border border-fx-border text-amber-300">
              <Moon className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center space-x-2">
                <span className="text-sm font-semibold text-fx-text">Dark Mode (Default)</span>
                {theme === 'dark' && (
                  <span className="text-[10px] font-mono font-semibold text-fx-teal">ACTIVE</span>
                )}
              </div>
              <p className="text-xs text-fx-muted mt-1 leading-relaxed">
                Institutional dark aesthetic with #050707 background, deep teal highlights, and low-glare financial charting.
              </p>
            </div>
          </button>

          {/* Light Mode Card */}
          <button
            onClick={() => setTheme('light')}
            className={`p-4 rounded-xl border text-left transition-all flex items-start space-x-3.5 ${
              theme === 'light'
                ? 'border-fx-teal bg-teal-500/10 shadow-glow-teal'
                : 'border-fx-border bg-fx-elevated/40 hover:bg-fx-elevated'
            }`}
          >
            <div className="p-2.5 rounded-lg bg-white border border-slate-300 text-amber-600">
              <Sun className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center space-x-2">
                <span className="text-sm font-semibold text-fx-text">Light Mode</span>
                {theme === 'light' && (
                  <span className="text-[10px] font-mono font-semibold text-fx-teal">ACTIVE</span>
                )}
              </div>
              <p className="text-xs text-fx-muted mt-1 leading-relaxed">
                Clean daylight financial aesthetic with #F5F8F7 background, high contrast typography, and crisp borders.
              </p>
            </div>
          </button>
        </div>
      </div>

      {/* Section 2: Currency & Regional Preferences */}
      <div className="p-6 rounded-2xl border border-fx-border bg-fx-card shadow-subtle space-y-4">
        <div className="pb-3 border-b border-fx-border/60">
          <h3 className="text-sm font-semibold text-fx-text">Currency & Corridor Preferences</h3>
          <p className="text-xs text-fx-muted mt-0.5">
            Default base trading currencies for conversions and audit summaries
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div>
            <label className="block text-xs font-medium text-fx-muted mb-1.5">
              Default Base Currency (Sending)
            </label>
            <select
              value={baseCurrency}
              onChange={(e) => setBaseCurrency(e.target.value as CurrencyCode)}
              className="w-full bg-fx-elevated text-fx-text text-xs border border-fx-border rounded-lg p-2.5 focus:outline-none focus:border-fx-teal cursor-pointer"
            >
              {SUPPORTED_CURRENCIES.map((c) => (
                <option key={c.code} value={c.code}>
                  {c.flag} {c.code} — {c.name} ({c.symbol})
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-xs font-medium text-fx-muted mb-1.5">
              Default Counter Currency (Settlement)
            </label>
            <select
              value={targetCurrency}
              onChange={(e) => setTargetCurrency(e.target.value as CurrencyCode)}
              className="w-full bg-fx-elevated text-fx-text text-xs border border-fx-border rounded-lg p-2.5 focus:outline-none focus:border-fx-teal cursor-pointer"
            >
              {SUPPORTED_CURRENCIES.map((c) => (
                <option key={c.code} value={c.code}>
                  {c.flag} {c.code} — {c.name} ({c.symbol})
                </option>
              ))}
            </select>
          </div>
        </div>
      </div>

      {/* Section 3: Notification & Spread Alerts */}
      <div className="p-6 rounded-2xl border border-fx-border bg-fx-card shadow-subtle space-y-4">
        <div className="pb-3 border-b border-fx-border/60">
          <h3 className="text-sm font-semibold text-fx-text">FX Markup & Anomaly Alerts</h3>
          <p className="text-xs text-fx-muted mt-0.5">
            Receive automated alerts when payment providers widen conversion spreads
          </p>
        </div>

        <div className="space-y-4">
          <div>
            <div className="flex justify-between items-center text-xs mb-1.5">
              <span className="font-medium text-fx-text">Spread Markup Alert Threshold:</span>
              <span className="font-mono font-bold text-rose-400">{alertThreshold}%</span>
            </div>
            <input
              type="range"
              min="1.0"
              max="5.0"
              step="0.1"
              value={alertThreshold}
              onChange={(e) => setAlertThreshold(parseFloat(e.target.value))}
              className="w-full accent-fx-teal h-2 bg-fx-elevated rounded-lg cursor-pointer"
            />
            <span className="text-[11px] text-fx-muted mt-1 block">
              Flag transactions when provider fee spread exceeds {alertThreshold}%.
            </span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 pt-3 border-t border-fx-border/50">
            <label className="flex items-center space-x-2.5 p-3 rounded-lg border border-fx-border bg-fx-elevated/40 cursor-pointer">
              <input
                type="checkbox"
                checked={emailAlerts}
                onChange={(e) => setEmailAlerts(e.target.checked)}
                className="accent-fx-teal rounded w-4 h-4"
              />
              <span className="text-xs text-fx-text font-medium">Email Alerts</span>
            </label>

            <label className="flex items-center space-x-2.5 p-3 rounded-lg border border-fx-border bg-fx-elevated/40 cursor-pointer">
              <input
                type="checkbox"
                checked={spikeAlerts}
                onChange={(e) => setSpikeAlerts(e.target.checked)}
                className="accent-fx-teal rounded w-4 h-4"
              />
              <span className="text-xs text-fx-text font-medium">Rate Spike Warnings</span>
            </label>

            <label className="flex items-center space-x-2.5 p-3 rounded-lg border border-fx-border bg-fx-elevated/40 cursor-pointer">
              <input
                type="checkbox"
                checked={dailyDigest}
                onChange={(e) => setDailyDigest(e.target.checked)}
                className="accent-fx-teal rounded w-4 h-4"
              />
              <span className="text-xs text-fx-text font-medium">Daily FX Digest</span>
            </label>
          </div>
        </div>
      </div>

      {/* Section 4: Profile Information */}
      <div className="p-6 rounded-2xl border border-fx-border bg-fx-card shadow-subtle space-y-4">
        <div className="pb-3 border-b border-fx-border/60">
          <h3 className="text-sm font-semibold text-fx-text">Merchant Profile Information</h3>
          <p className="text-xs text-fx-muted mt-0.5">
            Organization and business entity settings
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div>
            <label className="block text-xs font-medium text-fx-muted mb-1.5">Merchant Name</label>
            <input
              type="text"
              value={merchantName}
              onChange={(e) => setMerchantName(e.target.value)}
              className="w-full bg-fx-elevated text-fx-text text-xs border border-fx-border rounded-lg p-2.5 focus:outline-none focus:border-fx-teal font-medium"
            />
          </div>

          <div>
            <label className="block text-xs font-medium text-fx-muted mb-1.5">Business Entity</label>
            <input
              type="text"
              value={businessEntity}
              onChange={(e) => setBusinessEntity(e.target.value)}
              className="w-full bg-fx-elevated text-fx-text text-xs border border-fx-border rounded-lg p-2.5 focus:outline-none focus:border-fx-teal font-medium"
            />
          </div>
        </div>
      </div>

      {/* Section 5: Python FastAPI Backend Readiness Hub */}
      <div className="p-6 rounded-2xl border border-teal-500/30 bg-fx-card shadow-subtle space-y-4">
        <div className="flex items-center justify-between pb-3 border-b border-fx-border/60">
          <div className="flex items-center space-x-2.5">
            <div className="p-2 rounded-lg bg-teal-500/10 border border-teal-500/20 text-fx-teal">
              <Server className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-sm font-semibold text-fx-text">
                FastAPI Backend Integration Hub
              </h3>
              <p className="text-xs text-fx-muted">
                Pre-configured connection point for Python FastAPI & ML prediction backend
              </p>
            </div>
          </div>
          <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-fx-elevated text-fx-teal border border-fx-border">
            Standalone Mock Active
          </span>
        </div>

        <div className="space-y-4">
          <div>
            <label className="block text-xs font-medium text-fx-muted mb-1.5">
              Backend Endpoint URL
            </label>
            <div className="flex space-x-2">
              <input
                type="text"
                value={fastApiUrl}
                onChange={(e) => setFastApiUrl(e.target.value)}
                className="flex-1 bg-fx-elevated text-fx-text font-mono text-xs border border-fx-border rounded-lg px-3 py-2 focus:outline-none focus:border-fx-teal"
              />
              <button
                onClick={handleTestFastAPI}
                disabled={isTestingConnection}
                className="px-4 py-2 rounded-lg border border-fx-border bg-fx-elevated hover:bg-fx-card text-xs font-medium text-fx-text transition-colors"
              >
                {isTestingConnection ? 'Testing...' : 'Test Connection'}
              </button>
            </div>
          </div>

          <div>
            <label className="block text-xs font-medium text-fx-muted mb-1.5">
              API Bearer Token (Simulated)
            </label>
            <div className="flex space-x-2">
              <input
                type="password"
                readOnly
                value={mockApiKey}
                className="flex-1 bg-fx-elevated text-fx-muted font-mono text-xs border border-fx-border rounded-lg px-3 py-2 cursor-not-allowed"
              />
              <button
                onClick={handleCopyApiKey}
                className="p-2 rounded-lg border border-fx-border bg-fx-elevated hover:bg-fx-card text-fx-muted hover:text-fx-text transition-colors"
                title="Copy Token"
              >
                <Copy className="w-4 h-4" />
              </button>
            </div>
          </div>

          <div className="p-3.5 rounded-lg border border-fx-border bg-fx-elevated/40 text-xs font-mono space-y-1">
            <span className="text-fx-muted uppercase text-[10px] block">
              Pre-Wired Backend Endpoints:
            </span>
            <div className="text-fx-text">POST /api/v1/quotes/calculate</div>
            <div className="text-fx-text">GET  /api/v1/rates/history</div>
            <div className="text-fx-text">GET  /api/v1/transactions</div>
            <div className="text-fx-text">POST /api/v1/agent/chat</div>
          </div>
        </div>
      </div>

      {/* Section 6: About FXPilot AI */}
      <div className="p-6 rounded-2xl border border-fx-border bg-fx-card shadow-subtle text-xs space-y-3">
        <h4 className="font-semibold text-fx-text text-sm">About FXPilot AI</h4>
        <p className="text-fx-muted leading-relaxed">
          <strong>FXPilot AI</strong> is an AI-powered cross-border currency conversion intelligence platform built for international merchants, exporters, and fintech platforms. It audits payment gateway quotes, identifies hidden exchange rate margins, models interbank volatility, and provides tactical execution signals.
        </p>
        <div className="pt-2 flex flex-wrap items-center gap-4 text-[11px] text-fx-muted font-mono">
          <span>React 18 + TypeScript</span>
          <span>•</span>
          <span>Vite + Tailwind CSS</span>
          <span>•</span>
          <span>Recharts Analytics</span>
          <span>•</span>
          <span>AI Hackathon Build</span>
        </div>
      </div>
    </div>
  );
};
