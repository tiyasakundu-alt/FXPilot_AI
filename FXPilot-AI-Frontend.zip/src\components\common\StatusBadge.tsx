import React from 'react';
import { TransactionStatus } from '../../types';

interface StatusBadgeProps {
  status: TransactionStatus;
  size?: 'sm' | 'md';
}

export const StatusBadge: React.FC<StatusBadgeProps> = ({ status, size = 'md' }) => {
  const getStyles = () => {
    switch (status) {
      case 'Optimized':
        return 'bg-emerald-500/10 text-emerald-400 border-emerald-500/20';
      case 'Standard':
        return 'bg-slate-500/10 text-fx-muted border-fx-border';
      case 'High Markup':
        return 'bg-rose-500/10 text-rose-400 border-rose-500/25';
      case 'Pending Review':
        return 'bg-amber-500/10 text-amber-400 border-amber-500/20';
      default:
        return 'bg-slate-500/10 text-fx-muted border-fx-border';
    }
  };

  const dotColor = () => {
    switch (status) {
      case 'Optimized':
        return 'bg-emerald-400';
      case 'Standard':
        return 'bg-slate-400';
      case 'High Markup':
        return 'bg-rose-400';
      case 'Pending Review':
        return 'bg-amber-400';
    }
  };

  const sizeClass = size === 'sm' ? 'px-2 py-0.5 text-[11px]' : 'px-2.5 py-1 text-xs';

  return (
    <span
      className={`inline-flex items-center font-medium rounded-full border ${getStyles()} ${sizeClass} tracking-wide`}
    >
      <span className={`w-1.5 h-1.5 rounded-full mr-1.5 ${dotColor()}`} />
      {status}
    </span>
  );
};
