import { Currency, CurrencyCode, FXQuote, RateHistoryPoint, TimePeriod, Transaction, ChatMessage } from '../types';

export const SUPPORTED_CURRENCIES: Currency[] = [
  { code: 'USD', name: 'US Dollar', symbol: '$', flag: '🇺🇸', country: 'United States', decimalPlaces: 2 },
  { code: 'INR', name: 'Indian Rupee', symbol: '₹', flag: '🇮🇳', country: 'India', decimalPlaces: 2 },
  { code: 'EUR', name: 'Euro', symbol: '€', flag: '🇪🇺', country: 'European Union', decimalPlaces: 2 },
  { code: 'GBP', name: 'British Pound', symbol: '£', flag: '🇬🇧', country: 'United Kingdom', decimalPlaces: 2 },
  { code: 'JPY', name: 'Japanese Yen', symbol: '¥', flag: '🇯🇵', country: 'Japan', decimalPlaces: 0 },
  { code: 'AUD', name: 'Australian Dollar', symbol: 'A$', flag: '🇦🇺', country: 'Australia', decimalPlaces: 2 },
  { code: 'CAD', name: 'Canadian Dollar', symbol: 'C$', flag: '🇨🇦', country: 'Canada', decimalPlaces: 2 },
  { code: 'SGD', name: 'Singapore Dollar', symbol: 'S$', flag: '🇸🇬', country: 'Singapore', decimalPlaces: 2 },
];

// Base mid-market rates against 1 USD
export const BASE_RATES_TO_USD: Record<CurrencyCode, number> = {
  USD: 1.0000,
  INR: 86.4250,
  EUR: 0.9245,
  GBP: 0.7860,
  JPY: 153.2500,
  AUD: 1.5310,
  CAD: 1.3865,
  SGD: 1.3420,
};

// Typical provider markup percentages (simulated PayPal cross-border)
export const PROVIDER_MARKUP_PERCENT: Record<CurrencyCode, number> = {
  INR: 3.25, // 3.25% markup on USD/INR
  EUR: 3.00,
  GBP: 3.00,
  USD: 3.00,
  JPY: 3.50,
  AUD: 3.20,
  CAD: 3.10,
  SGD: 3.15,
};

export function getMidMarketRate(from: CurrencyCode, to: CurrencyCode): number {
  if (from === to) return 1.0;
  const fromBase = BASE_RATES_TO_USD[from];
  const toBase = BASE_RATES_TO_USD[to];
  return toBase / fromBase;
}

export function getProviderRate(from: CurrencyCode, to: CurrencyCode): number {
  const mid = getMidMarketRate(from, to);
  const markup = (PROVIDER_MARKUP_PERCENT[to] || 3.1) / 100;
  // Provider gives fewer destination units per source unit
  return mid * (1 - markup);
}

// Generate realistic Historical Data for USD/INR
export function generateRateHistory(period: TimePeriod, pair: string = 'USD/INR'): RateHistoryPoint[] {
  const [from, to] = pair.split('/') as [CurrencyCode, CurrencyCode];
  const baseMid = getMidMarketRate(from, to);
  const markupPct = (PROVIDER_MARKUP_PERCENT[to] || 3.2) / 100;

  const points: RateHistoryPoint[] = [];
  const now = new Date();

  if (period === '1D') {
    // 24 intraday hourly points
    for (let i = 24; i >= 0; i--) {
      const time = new Date(now.getTime() - i * 3600 * 1000);
      const wave = Math.sin(i * 0.4) * 0.18 + Math.cos(i * 0.7) * 0.12;
      const mid = Number((baseMid + wave).toFixed(4));
      const prov = Number((mid * (1 - markupPct)).toFixed(4));
      points.push({
        date: time.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        timestamp: time.getTime(),
        midMarket: mid,
        provider: prov,
        spread: Number((mid - prov).toFixed(4)),
        markupPercent: Number(((mid - prov) / mid * 100).toFixed(2)),
        high: Number((mid + 0.08).toFixed(4)),
        low: Number((mid - 0.07).toFixed(4)),
      });
    }
  } else if (period === '1W') {
    // 7 daily points
    for (let i = 7; i >= 0; i--) {
      const time = new Date(now.getTime() - i * 24 * 3600 * 1000);
      const wave = Math.sin(i * 0.8) * 0.45 - (i * 0.05);
      const mid = Number((baseMid + wave).toFixed(4));
      const prov = Number((mid * (1 - markupPct)).toFixed(4));
      points.push({
        date: time.toLocaleDateString([], { month: 'short', day: 'numeric' }),
        timestamp: time.getTime(),
        midMarket: mid,
        provider: prov,
        spread: Number((mid - prov).toFixed(4)),
        markupPercent: Number(((mid - prov) / mid * 100).toFixed(2)),
        high: Number((mid + 0.22).toFixed(4)),
        low: Number((mid - 0.18).toFixed(4)),
      });
    }
  } else if (period === '1M') {
    // 30 daily points
    for (let i = 30; i >= 0; i--) {
      const time = new Date(now.getTime() - i * 24 * 3600 * 1000);
      const trend = (30 - i) * 0.04;
      const wave = Math.sin(i * 0.5) * 0.6 + Math.cos(i * 0.3) * 0.3;
      const mid = Number((baseMid - 1.2 + trend + wave).toFixed(4));
      const prov = Number((mid * (1 - markupPct)).toFixed(4));
      points.push({
        date: time.toLocaleDateString([], { month: 'short', day: 'numeric' }),
        timestamp: time.getTime(),
        midMarket: mid,
        provider: prov,
        spread: Number((mid - prov).toFixed(4)),
        markupPercent: Number(((mid - prov) / mid * 100).toFixed(2)),
        high: Number((mid + 0.35).toFixed(4)),
        low: Number((mid - 0.30).toFixed(4)),
      });
    }
  } else if (period === '3M') {
    // 90 days sampled every 3 days
    for (let i = 90; i >= 0; i -= 3) {
      const time = new Date(now.getTime() - i * 24 * 3600 * 1000);
      const trend = (90 - i) * 0.025;
      const wave = Math.sin(i * 0.15) * 0.95;
      const mid = Number((baseMid - 2.1 + trend + wave).toFixed(4));
      const prov = Number((mid * (1 - markupPct)).toFixed(4));
      points.push({
        date: time.toLocaleDateString([], { month: 'short', day: 'numeric' }),
        timestamp: time.getTime(),
        midMarket: mid,
        provider: prov,
        spread: Number((mid - prov).toFixed(4)),
        markupPercent: Number(((mid - prov) / mid * 100).toFixed(2)),
        high: Number((mid + 0.55).toFixed(4)),
        low: Number((mid - 0.48).toFixed(4)),
      });
    }
  } else {
    // 1Y sampled every 15 days
    for (let i = 365; i >= 0; i -= 15) {
      const time = new Date(now.getTime() - i * 24 * 3600 * 1000);
      const trend = (365 - i) * 0.012;
      const wave = Math.sin(i * 0.05) * 1.4;
      const mid = Number((baseMid - 3.8 + trend + wave).toFixed(4));
      const prov = Number((mid * (1 - markupPct)).toFixed(4));
      points.push({
        date: time.toLocaleDateString([], { month: 'short', year: '2-digit' }),
        timestamp: time.getTime(),
        midMarket: mid,
        provider: prov,
        spread: Number((mid - prov).toFixed(4)),
        markupPercent: Number(((mid - prov) / mid * 100).toFixed(2)),
        high: Number((mid + 0.85).toFixed(4)),
        low: Number((mid - 0.75).toFixed(4)),
      });
    }
  }

  return points;
}

// Comprehensive Conversion Calculator
export function calculateQuote(from: CurrencyCode, to: CurrencyCode, amount: number): FXQuote {
  const midMarketRate = getMidMarketRate(from, to);
  const providerRate = getProviderRate(from, to);
  const markupPercent = Number(((midMarketRate - providerRate) / midMarketRate * 100).toFixed(2));
  
  const convertedMidMarket = amount * midMarketRate;
  const convertedProvider = amount * providerRate;
  const differenceAmount = convertedMidMarket - convertedProvider;
  
  // Cost in source currency
  const markupAmount = differenceAmount / midMarketRate;

  // Benchmarks
  const wiseRate = midMarketRate * (1 - 0.0042);
  const bankWireRate = midMarketRate * (1 - 0.0245);
  const stripeRate = midMarketRate * (1 - 0.0200);

  return {
    id: `QUOTE-${Math.random().toString(36).substring(2, 9).toUpperCase()}`,
    fromCurrency: from,
    toCurrency: to,
    amount,
    midMarketRate: Number(midMarketRate.toFixed(4)),
    providerRate: Number(providerRate.toFixed(4)),
    markupPercent,
    markupAmount: Number(markupAmount.toFixed(2)),
    convertedMidMarket: Number(convertedMidMarket.toFixed(2)),
    convertedProvider: Number(convertedProvider.toFixed(2)),
    differenceAmount: Number(differenceAmount.toFixed(2)),
    timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' }),
    providerName: 'PayPal Commercial Quote (Simulated)',
    benchmarks: {
      wise: {
        rate: Number(wiseRate.toFixed(4)),
        received: Number((amount * wiseRate).toFixed(2)),
        fee: Number((amount * 0.0042).toFixed(2)),
        markupPercent: 0.42,
      },
      bankWire: {
        rate: Number(bankWireRate.toFixed(4)),
        received: Number((amount * bankWireRate).toFixed(2)),
        fee: Number((amount * 0.0245).toFixed(2)),
        markupPercent: 2.45,
      },
      stripe: {
        rate: Number(stripeRate.toFixed(4)),
        received: Number((amount * stripeRate).toFixed(2)),
        fee: Number((amount * 0.0200).toFixed(2)),
        markupPercent: 2.00,
      },
    },
  };
}

// Mock Transactions (30 realistic transactions)
export const MOCK_TRANSACTIONS: Transaction[] = [
  {
    id: 'TXN-9021-USD',
    date: '2026-11-06',
    time: '18:42:10',
    currencyPair: 'USD/INR',
    fromCurrency: 'USD',
    toCurrency: 'INR',
    fromAmount: 5000,
    toAmount: 418525,
    midMarketRate: 86.4250,
    providerRate: 83.7050,
    fxMarkupPercent: 3.15,
    fxMarkupLoss: 157.50,
    status: 'Standard',
    merchantName: 'CloudScale Infrastructure LLC',
    paymentMethod: 'PayPal Balance Express',
    referenceId: 'PAYPAL-REF-8942-A',
  },
  {
    id: 'TXN-9020-EUR',
    date: '2026-11-06',
    time: '14:22:04',
    currencyPair: 'EUR/INR',
    fromCurrency: 'EUR',
    toCurrency: 'INR',
    fromAmount: 12400,
    toAmount: 1121540,
    midMarketRate: 93.4830,
    providerRate: 90.4468,
    fxMarkupPercent: 3.25,
    fxMarkupLoss: 403.00,
    status: 'High Markup',
    merchantName: 'Nordic Creative Agency ApS',
    paymentMethod: 'PayPal Commercial Checkout',
    referenceId: 'PAYPAL-REF-8871-B',
  },
  {
    id: 'TXN-9019-USD',
    date: '2026-11-05',
    time: '21:05:45',
    currencyPair: 'USD/INR',
    fromCurrency: 'USD',
    toCurrency: 'INR',
    fromAmount: 25000,
    toAmount: 2125850,
    midMarketRate: 86.3500,
    providerRate: 85.0340,
    fxMarkupPercent: 1.52,
    fxMarkupLoss: 380.00,
    status: 'Optimized',
    merchantName: 'Apex SaaS Platforms Ltd',
    paymentMethod: 'PayPal Batch Settlement',
    referenceId: 'PAYPAL-REF-8812-C',
  },
  {
    id: 'TXN-9018-GBP',
    date: '2026-11-05',
    time: '11:18:22',
    currencyPair: 'GBP/INR',
    fromCurrency: 'GBP',
    toCurrency: 'INR',
    fromAmount: 4200,
    toAmount: 444310,
    midMarketRate: 109.9550,
    providerRate: 105.7880,
    fxMarkupPercent: 3.79,
    fxMarkupLoss: 159.18,
    status: 'High Markup',
    merchantName: 'London Fintech Studio',
    paymentMethod: 'PayPal Standard Invoice',
    referenceId: 'PAYPAL-REF-8760-D',
  },
  {
    id: 'TXN-9017-USD',
    date: '2026-11-04',
    time: '16:50:33',
    currencyPair: 'USD/EUR',
    fromCurrency: 'USD',
    toCurrency: 'EUR',
    fromAmount: 18500,
    toAmount: 16578,
    midMarketRate: 0.9245,
    providerRate: 0.8961,
    fxMarkupPercent: 3.07,
    fxMarkupLoss: 567.95,
    status: 'Standard',
    merchantName: 'Stripe Global Gateway Payout',
    paymentMethod: 'PayPal Merchant Payout',
    referenceId: 'PAYPAL-REF-8705-E',
  },
  {
    id: 'TXN-9016-AUD',
    date: '2026-11-04',
    time: '09:12:15',
    currencyPair: 'AUD/INR',
    fromCurrency: 'AUD',
    toCurrency: 'INR',
    fromAmount: 8900,
    toAmount: 485050,
    midMarketRate: 56.4500,
    providerRate: 54.5000,
    fxMarkupPercent: 3.45,
    fxMarkupLoss: 307.05,
    status: 'Standard',
    merchantName: 'Sydney Pacific Digital Pty',
    paymentMethod: 'PayPal Cross-Border Direct',
    referenceId: 'PAYPAL-REF-8641-F',
  },
  {
    id: 'TXN-9015-USD',
    date: '2026-11-03',
    time: '19:30:00',
    currencyPair: 'USD/INR',
    fromCurrency: 'USD',
    toCurrency: 'INR',
    fromAmount: 32000,
    toAmount: 2727100,
    midMarketRate: 86.2000,
    providerRate: 85.2230,
    fxMarkupPercent: 1.13,
    fxMarkupLoss: 361.60,
    status: 'Optimized',
    merchantName: 'Silicon Valley Labs Corp',
    paymentMethod: 'PayPal Enterprise Routed',
    referenceId: 'PAYPAL-REF-8588-G',
  },
  {
    id: 'TXN-9014-CAD',
    date: '2026-11-03',
    time: '13:45:12',
    currencyPair: 'CAD/INR',
    fromCurrency: 'CAD',
    toCurrency: 'INR',
    fromAmount: 6500,
    toAmount: 388700,
    midMarketRate: 62.3330,
    providerRate: 59.8000,
    fxMarkupPercent: 4.06,
    fxMarkupLoss: 263.90,
    status: 'High Markup',
    merchantName: 'Toronto Interactive Soft',
    paymentMethod: 'PayPal Standard Invoice',
    referenceId: 'PAYPAL-REF-8512-H',
  },
  {
    id: 'TXN-9013-SGD',
    date: '2026-11-02',
    time: '08:24:50',
    currencyPair: 'SGD/INR',
    fromCurrency: 'SGD',
    toCurrency: 'INR',
    fromAmount: 15000,
    toAmount: 939000,
    midMarketRate: 64.4000,
    providerRate: 62.6000,
    fxMarkupPercent: 2.79,
    fxMarkupLoss: 418.50,
    status: 'Standard',
    merchantName: 'Marina Bay Logistics Pte',
    paymentMethod: 'PayPal Direct Debit',
    referenceId: 'PAYPAL-REF-8470-I',
  },
  {
    id: 'TXN-9012-USD',
    date: '2026-11-01',
    time: '17:15:39',
    currencyPair: 'USD/INR',
    fromCurrency: 'USD',
    toCurrency: 'INR',
    fromAmount: 7800,
    toAmount: 651690,
    midMarketRate: 86.1500,
    providerRate: 83.5500,
    fxMarkupPercent: 3.02,
    fxMarkupLoss: 235.56,
    status: 'Standard',
    merchantName: 'Boston Healthtech Inc',
    paymentMethod: 'PayPal API Checkout',
    referenceId: 'PAYPAL-REF-8419-J',
  },
  {
    id: 'TXN-9011-EUR',
    date: '2026-10-31',
    time: '15:10:02',
    currencyPair: 'EUR/INR',
    fromCurrency: 'EUR',
    toCurrency: 'INR',
    fromAmount: 22000,
    toAmount: 2021800,
    midMarketRate: 93.3000,
    providerRate: 91.9000,
    fxMarkupPercent: 1.50,
    fxMarkupLoss: 330.00,
    status: 'Optimized',
    merchantName: 'Munich Auto Mobility GmbH',
    paymentMethod: 'PayPal Commercial Direct',
    referenceId: 'PAYPAL-REF-8370-K',
  },
  {
    id: 'TXN-9010-JPY',
    date: '2026-10-30',
    time: '10:05:14',
    currencyPair: 'JPY/INR',
    fromCurrency: 'JPY',
    toCurrency: 'INR',
    fromAmount: 1800000,
    toAmount: 981000,
    midMarketRate: 0.5640,
    providerRate: 0.5450,
    fxMarkupPercent: 3.37,
    fxMarkupLoss: 337.00,
    status: 'Standard',
    merchantName: 'Tokyo Robotics Studio Inc',
    paymentMethod: 'PayPal International Wire',
    referenceId: 'PAYPAL-REF-8311-L',
  },
  {
    id: 'TXN-9009-USD',
    date: '2026-10-29',
    time: '20:18:41',
    currencyPair: 'USD/INR',
    fromCurrency: 'USD',
    toCurrency: 'INR',
    fromAmount: 14500,
    toAmount: 1209300,
    midMarketRate: 86.0500,
    providerRate: 83.4000,
    fxMarkupPercent: 3.08,
    fxMarkupLoss: 446.60,
    status: 'Standard',
    merchantName: 'Austin Cybernetics Ltd',
    paymentMethod: 'PayPal Standard Invoice',
    referenceId: 'PAYPAL-REF-8260-M',
  },
  {
    id: 'TXN-9008-GBP',
    date: '2026-10-28',
    time: '12:40:55',
    currencyPair: 'GBP/USD',
    fromCurrency: 'GBP',
    toCurrency: 'USD',
    fromAmount: 9800,
    toAmount: 12054,
    midMarketRate: 1.2720,
    providerRate: 1.2300,
    fxMarkupPercent: 3.30,
    fxMarkupLoss: 323.40,
    status: 'Standard',
    merchantName: 'Edinburgh Cloud Compute',
    paymentMethod: 'PayPal Business Account',
    referenceId: 'PAYPAL-REF-8199-N',
  },
  {
    id: 'TXN-9007-USD',
    date: '2026-10-27',
    time: '14:55:18',
    currencyPair: 'USD/INR',
    fromCurrency: 'USD',
    toCurrency: 'INR',
    fromAmount: 50000,
    toAmount: 4252500,
    midMarketRate: 85.9500,
    providerRate: 85.0500,
    fxMarkupPercent: 1.05,
    fxMarkupLoss: 525.00,
    status: 'Optimized',
    merchantName: 'Apex Merchant Holding AG',
    paymentMethod: 'PayPal Wholesale Settlement',
    referenceId: 'PAYPAL-REF-8142-O',
  },
  {
    id: 'TXN-9006-USD',
    date: '2026-10-25',
    time: '19:12:44',
    currencyPair: 'USD/INR',
    fromCurrency: 'USD',
    toCurrency: 'INR',
    fromAmount: 3800,
    toAmount: 312360,
    midMarketRate: 85.8000,
    providerRate: 82.2000,
    fxMarkupPercent: 4.20,
    fxMarkupLoss: 159.60,
    status: 'High Markup',
    merchantName: 'Seattle App Developers Co',
    paymentMethod: 'PayPal Express Weekend',
    referenceId: 'PAYPAL-REF-8090-P',
  },
  {
    id: 'TXN-9005-EUR',
    date: '2026-10-24',
    time: '11:08:29',
    currencyPair: 'EUR/INR',
    fromCurrency: 'EUR',
    toCurrency: 'INR',
    fromAmount: 8500,
    toAmount: 771800,
    midMarketRate: 93.1000,
    providerRate: 90.8000,
    fxMarkupPercent: 2.47,
    fxMarkupLoss: 209.95,
    status: 'Pending Review',
    merchantName: 'Amsterdam Logistics BV',
    paymentMethod: 'PayPal Business Transfer',
    referenceId: 'PAYPAL-REF-8015-Q',
  },
  {
    id: 'TXN-9004-AUD',
    date: '2026-10-22',
    time: '08:44:11',
    currencyPair: 'AUD/INR',
    fromCurrency: 'AUD',
    toCurrency: 'INR',
    fromAmount: 11200,
    toAmount: 609280,
    midMarketRate: 56.2000,
    providerRate: 54.4000,
    fxMarkupPercent: 3.20,
    fxMarkupLoss: 358.40,
    status: 'Standard',
    merchantName: 'Melbourne Media Group',
    paymentMethod: 'PayPal Commercial Direct',
    referenceId: 'PAYPAL-REF-7950-R',
  },
  {
    id: 'TXN-9003-USD',
    date: '2026-10-20',
    time: '16:33:50',
    currencyPair: 'USD/INR',
    fromCurrency: 'USD',
    toCurrency: 'INR',
    fromAmount: 16000,
    toAmount: 1334400,
    midMarketRate: 85.7000,
    providerRate: 83.4000,
    fxMarkupPercent: 2.68,
    fxMarkupLoss: 428.80,
    status: 'Standard',
    merchantName: 'San Francisco Design Lab',
    paymentMethod: 'PayPal API Checkout',
    referenceId: 'PAYPAL-REF-7890-S',
  },
  {
    id: 'TXN-9002-GBP',
    date: '2026-10-18',
    time: '13:19:07',
    currencyPair: 'GBP/INR',
    fromCurrency: 'GBP',
    toCurrency: 'INR',
    fromAmount: 14000,
    toAmount: 1500800,
    midMarketRate: 109.5000,
    providerRate: 107.2000,
    fxMarkupPercent: 2.10,
    fxMarkupLoss: 294.00,
    status: 'Optimized',
    merchantName: 'Cambridge Biotechnology UK',
    paymentMethod: 'PayPal Priority Wire',
    referenceId: 'PAYPAL-REF-7811-T',
  },
];

// Initial AI Agent Conversation
export const INITIAL_CHAT_MESSAGES: ChatMessage[] = [
  {
    id: 'msg-welcome',
    sender: 'assistant',
    content: `Hello! I am **FXPilot AI**, your institutional currency conversion intelligence copilot.

I continuously analyze mid-market FX rates, evaluate PayPal conversion quotes, detect hidden spread markups, and calculate optimal conversion timing for cross-border merchants.

**How can I assist you today?** Select a prompt below or type your custom transaction scenario.`,
    timestamp: 'Just now',
  },
];

// Contextual AI response generator
export function getSimulatedAIResponse(userQuery: string): ChatMessage {
  const query = userQuery.toLowerCase();
  const id = `msg-${Date.now()}`;
  const timestamp = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });

  // Scenario 1: "$5,000 USD to INR" or amount specific
  if (query.includes('5000') || query.includes('5,000') || (query.includes('usd') && query.includes('inr') && query.includes('conver'))) {
    return {
      id,
      sender: 'assistant',
      content: `### Conversion Analysis: $5,000 USD → INR

Based on current institutional reference feeds:

- **Mid-Market Reference Rate:** 1 USD = ₹86.4250
- **PayPal Quoted Rate (Simulated):** 1 USD = ₹83.6162
- **Estimated FX Markup:** **3.25%** (Spread: ₹2.8088 / USD)

#### Financial Impact Breakdown:
- **Fair Value (Mid-Market):** ₹432,125.00
- **Expected Received via PayPal:** ₹418,081.00
- **Conversion Markup Loss:** **-₹14,044.00 (~$162.50 USD)**

#### FXPilot Tactical Recommendation:
1. **Timing:** USD/INR is trading near 24-hour resistance (86.48). Executing during active Asian-European overlap (07:00 – 11:00 UTC) typically yields tighter provider settlement spreads.
2. **Alternative Route:** Routing through institutional local clearing or multi-currency account could recover ~₹12,200 of the markup loss.`,
      timestamp,
      analysis: {
        pair: 'USD/INR',
        amount: 5000,
        referenceRate: 86.4250,
        providerRate: 83.6162,
        markupPercent: 3.25,
        markupLoss: 162.50,
        recommendation: 'OPTIMIZE ROUTE',
        confidence: 94,
        rationale: 'High 3.25% retail spread detected on commercial batch.',
      },
    };
  }

  // Scenario 2: "Compare current reference and provider rates"
  if (query.includes('compare') || query.includes('reference and provider') || query.includes('rates')) {
    return {
      id,
      sender: 'assistant',
      content: `### Real-Time Spread Audit: Mid-Market vs PayPal Quotes

Here is the current comparative spread audit across your primary currency corridors:

| Corridor | Mid-Market Ref | PayPal Simulated Quote | Hidden Markup | 24h Volatility |
| :--- | :--- | :--- | :--- | :--- |
| **USD / INR** | 86.4250 | 83.6162 | **3.25%** | 0.28% (Low) |
| **EUR / INR** | 93.4830 | 90.4448 | **3.25%** | 0.42% (Normal) |
| **GBP / INR** | 109.9550 | 106.6563 | **3.00%** | 0.58% (Moderate) |
| **USD / EUR** | 0.9245 | 0.8968 | **3.00%** | 0.31% (Low) |

**Key Takeaway:** The highest margin capture is currently observed on **Asian corridor payouts (INR, JPY)** where cross-border retail margins expand beyond 3.2%. Corridors with high liquidity (USD/EUR) remain around 3.00%.`,
      timestamp,
      analysis: {
        pair: 'MULTI-CORRIDOR',
        referenceRate: 86.4250,
        providerRate: 83.6162,
        markupPercent: 3.25,
        markupLoss: 280.88,
        recommendation: 'MONITOR SPREAD' as any,
        confidence: 96,
        rationale: 'Cross-border spread disparity highest on INR corridors.',
      },
    };
  }

  // Scenario 3: "Explain how much markup I am paying" or "markup"
  if (query.includes('markup') || query.includes('paying') || query.includes('hidden') || query.includes('cost')) {
    return {
      id,
      sender: 'assistant',
      content: `### Portfolio FX Markup Audit

Across your **248 transactions analyzed** totaling **$128,450.00 USD equivalent**:

- **Weighted Average FX Markup:** **1.42%** (down from 1.70% last period)
- **Total Markup Paid to Date:** **$1,823.99 USD** (~₹157,638 INR)
- **Standard Benchmark Retail Markup:** 3.25% (You have saved **$2,350.00** via batch routing)
- **Maximum Markup Recorded:** **4.20%** on off-market weekend conversions.

#### Why do providers charge this?
Payment gateways bundle a retail foreign exchange margin on top of standard payment processing fees (e.g. 2.9% + $0.30). This FX margin is often not broken down on line items, functioning as a hidden cost on cross-border merchant payouts.

#### Actionable Steps:
- Enable **Automated Weekend Hold** in FXPilot Settings to prevent auto-conversion during illiquid market hours.
- Set alert threshold to **2.50%** to flag high-spread invoices before approval.`,
      timestamp,
      analysis: {
        pair: 'GLOBAL PORTFOLIO',
        referenceRate: 1.0000,
        providerRate: 0.9858,
        markupPercent: 1.42,
        markupLoss: 1823.99,
        recommendation: 'CONVERT NOW',
        confidence: 91,
        rationale: 'Batch scheduling is successfully capturing 1.42% effective spread.',
      },
    };
  }

  // Scenario 4: "Should I convert now or wait?" or "convert now" or "wait"
  if (query.includes('now or wait') || query.includes('wait') || query.includes('timing') || query.includes('should i convert')) {
    return {
      id,
      sender: 'assistant',
      content: `### Execution Timing Signal: USD/INR

**Current Signal:** **HOLD / SHORT-TERM WAIT (Next 6–12 Hours)**

#### Technical & Structural Indicators:
1. **Exchange Rate Momentum:** USD/INR is currently testing resistance at **86.48**. The 14-day RSI stands at 64.2 (moderately overbought).
2. **Provider Spread Dynamics:** Providers typically widen retail spreads Friday evening after US market close by an extra **+0.35% to +0.60%** to hedge weekend liquidity risk.
3. **Projected Rate Movement:** Short-term mean reversion toward **86.25** is likely before the next FOMC statement.

#### Recommendation:
- If this conversion is non-critical, **delay batch execution until Monday morning (08:30 IST / 03:00 UTC)** when institutional market liquidity opens and spreads compress.
- Estimated potential savings on $20,000 batch: **~$180 USD (₹15,500 INR)**.`,
      timestamp,
      analysis: {
        pair: 'USD/INR',
        referenceRate: 86.4250,
        providerRate: 83.6162,
        markupPercent: 3.25,
        markupLoss: 650.00,
        recommendation: 'HOLD / WAIT',
        confidence: 88,
        rationale: 'Weekend liquidity gap widening projected.',
      },
    };
  }

  // Default intelligent assistant response
  return {
    id,
    sender: 'assistant',
    content: `### FXPilot Intelligence Report: "${userQuery}"

I analyzed your query against our institutional cross-border rate database.

- **Current Reference Pair:** USD/INR @ 86.4250
- **Provider Spread Band:** 3.10% – 3.35%
- **24-Hour Range:** 86.1800 – 86.4800

#### Key Strategic Insights:
1. **Spread Auditing:** Always verify the quoted exchange rate against the mid-market rate prior to initiating cross-border settlements.
2. **Batch Consolidations:** Aggregating micro-transactions into larger periodic conversions reduces fixed provider wire fees and opens tiered FX rate brackets.
3. **FastAPI Backend Integration:** When connected to your Python backend engine, FXPilot will stream live sub-millisecond order-book quotes and ML-driven volatility forecasts.

Feel free to ask for a specific amount conversion, historical volatility analysis, or provider rate audit.`,
    timestamp,
    analysis: {
      pair: 'USD/INR',
      referenceRate: 86.4250,
      providerRate: 83.6162,
      markupPercent: 3.25,
      markupLoss: 162.50,
      recommendation: 'CONVERT NOW',
      confidence: 85,
      rationale: 'Simulated institutional analysis complete.',
    },
  };
}
