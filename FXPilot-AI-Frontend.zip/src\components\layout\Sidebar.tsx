import React from 'react';
import { NavLink, useLocation } from 'react-router-dom';
import {
  LayoutDashboard,
  ArrowLeftRight,
  LineChart,
  Bot,
  History,
  Settings,
  ChevronLeft,
  ChevronRight,
  X,
  Compass,
  Cpu,
} from 'lucide-react';

interface SidebarProps {
  collapsed: boolean;
  onToggleCollapse: () => void;
  mobileOpen: boolean;
  onCloseMobile: () => void;
}

export const Sidebar: React.FC<SidebarProps> = ({
  collapsed,
  onToggleCollapse,
  mobileOpen,
  onCloseMobile,
}) => {
  const location = useLocation();

  const navItems = [
    { name: 'Overview', path: '/', icon: LayoutDashboard },
    { name: 'FX Converter', path: '/converter', icon: ArrowLeftRight },
    { name: 'FX Analytics', path: '/analytics', icon: LineChart },
    { name: 'AI Agent', path: '/agent', icon: Bot, badge: 'AI' },
    { name: 'Transactions', path: '/transactions', icon: History },
    { name: 'Settings', path: '/settings', icon: Settings },
  ];

  return (
    <>
      {/* Mobile Backdrop */}
      {mobileOpen && (
        <div
          className="fixed inset-0 z-40 bg-black/60 backdrop-blur-sm lg:hidden"
          onClick={onCloseMobile}
        />
      )}

      {/* Sidebar Container */}
      <aside
        className={`fixed top-0 bottom-0 left-0 z-40 flex flex-col border-r border-fx-border bg-fx-sidebar transition-all duration-300 ease-in-out
          ${collapsed ? 'w-20' : 'w-64'}
          ${mobileOpen ? 'translate-x-0' : '-translate-x-full lg:translate-x-0'}
        `}
      >
        {/* Brand Header */}
        <div className="flex items-center justify-between h-16 px-4 border-b border-fx-border">
          <div className="flex items-center space-x-3 overflow-hidden">
            {/* Custom Logo Icon */}
            <div className="w-9 h-9 rounded-lg bg-teal-500/10 border border-teal-500/30 flex items-center justify-center shrink-0 shadow-glow-teal">
              <Compass className="w-5 h-5 text-fx-teal" />
            </div>

            {!collapsed && (
              <div className="flex flex-col truncate">
                <span className="text-base font-bold tracking-tight text-fx-text flex items-center">
                  FXPilot <span className="text-fx-teal ml-1">AI</span>
                </span>
                <span className="text-[10px] uppercase font-mono text-fx-muted tracking-widest truncate">
                  Cross-border FX Intel
                </span>
              </div>
            )}
          </div>

          {/* Mobile close button */}
          <button
            onClick={onCloseMobile}
            className="lg:hidden p-1.5 text-fx-muted hover:text-fx-text rounded-md"
            aria-label="Close menu"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Navigation Items */}
        <div className="flex-1 px-3 py-4 space-y-1 overflow-y-auto">
          {!collapsed && (
            <div className="px-3 pb-2 text-[10px] font-mono uppercase tracking-wider text-fx-muted">
              Platform
            </div>
          )}

          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive = location.pathname === item.path;

            return (
              <NavLink
                key={item.path}
                to={item.path}
                onClick={onCloseMobile}
                title={collapsed ? item.name : undefined}
                className={`group flex items-center relative rounded-lg px-3 py-2.5 text-xs font-medium transition-all duration-150
                  ${
                    isActive
                      ? 'bg-teal-500/15 text-fx-teal border border-teal-500/25 shadow-sm'
                      : 'text-fx-muted hover:text-fx-text hover:bg-fx-elevated border border-transparent'
                  }
                  ${collapsed ? 'justify-center' : 'space-x-3'}
                `}
              >
                {/* Active Indicator Bar */}
                {isActive && (
                  <span className="absolute left-0 top-2 bottom-2 w-1 rounded-r bg-fx-teal" />
                )}

                <Icon
                  className={`w-4 h-4 shrink-0 transition-colors ${
                    isActive ? 'text-fx-teal' : 'text-fx-muted group-hover:text-fx-text'
                  }`}
                />

                {!collapsed && (
                  <span className="flex-1 truncate">{item.name}</span>
                )}

                {!collapsed && item.badge && (
                  <span className="px-1.5 py-0.5 text-[9px] font-mono font-semibold rounded bg-fx-teal/20 text-fx-teal border border-fx-teal/30">
                    {item.badge}
                  </span>
                )}
              </NavLink>
            );
          })}
        </div>

        {/* Backend Readiness Mini Card */}
        {!collapsed && (
          <div className="p-3 mx-3 mb-3 rounded-lg border border-fx-border bg-fx-elevated/40">
            <div className="flex items-center space-x-2">
              <Cpu className="w-3.5 h-3.5 text-fx-teal" />
              <span className="text-[11px] font-medium text-fx-text">FastAPI Engine</span>
            </div>
            <p className="text-[10px] text-fx-muted mt-1 leading-relaxed">
              Standalone simulation mode active. Ready for Python backend connection.
            </p>
          </div>
        )}

        {/* Collapse Toggle Footer (Desktop only) */}
        <div className="hidden lg:flex items-center justify-between p-3 border-t border-fx-border">
          {!collapsed && (
            <div className="flex items-center space-x-2 text-[11px] text-fx-muted">
              <span className="w-2 h-2 rounded-full bg-fx-green animate-pulse" />
              <span>Simulated Feed</span>
            </div>
          )}
          <button
            onClick={onToggleCollapse}
            className={`p-1.5 rounded-lg border border-fx-border bg-fx-card hover:bg-fx-elevated text-fx-muted hover:text-fx-text transition-colors ${
              collapsed ? 'w-full flex justify-center' : ''
            }`}
            title={collapsed ? 'Expand sidebar' : 'Collapse sidebar'}
            aria-label="Toggle sidebar collapse"
          >
            {collapsed ? <ChevronRight className="w-4 h-4" /> : <ChevronLeft className="w-4 h-4" />}
          </button>
        </div>
      </aside>
    </>
  );
};
