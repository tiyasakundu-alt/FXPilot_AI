import React, { useState } from 'react';
import { Transaction } from '../../types';
import { MOCK_TRANSACTIONS } from '../../data/mockData';
import { StatusBadge } from '../common/StatusBadge';
import { formatCurrency, formatDate, formatPercent } from '../../utils/formatters';
import { ArrowUpRight, ArrowRight } from 'lucide-react';
import { Link } from 'react-router-dom';

interface RecentTransactionsProps {
  onSelectTransaction?: (txn: Transaction) => void;
}

export const RecentTransactions: React.FC<RecentTransactionsProps> = ({ onSelectTransaction }) => {
  const recentList = MOCK_TRANSACTIONS.slice(0, 6);

  return (
    <div className="p-5 rounded-xl border border-fx-border bg-fx-card shadow-subtle">
      {/* Table Header */}
      <div className="flex items-center justify-between pb-4 border-b border-fx-border/60">
        <div>
          <h3 className="text-sm font-semibold text-fx-text">Recent International Transactions</h3>
          <p className="text-[11px] text-fx-muted mt-0.5">
            Cross-border settlement history audited by FXPilot AI
          </p>
        </div>
        <Link
          to="/transactions"
          className="inline-flex items-center space-x-1 text-xs text-fx-teal hover:underline font-medium"
        >
          <span>View All Transactions</span>
          <ArrowRight className="w-3.5 h-3.5" />
        </Link>
      </div>

      {/* Table container */}
      <div className="overflow-x-auto mt-2">
        <table className="w-full text-left text-xs">
          <thead>
            <tr className="border-b border-fx-border text-fx-muted uppercase tracking-wider text-[10px] font-mono">
              <th className="py-3 px-2">Transaction ID</th>
              <th className="py-3 px-2">Date</th>
              <th className="py-3 px-2">Pair</th>
              <th className="py-3 px-2 text-right">Amount</th>
              <th className="py-3 px-2 text-right">FX Markup</th>
              <th className="py-3 px-2 text-center">Status</th>
              <th className="py-3 px-2 text-right">Action</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-fx-border/40 font-mono">
            {recentList.map((txn) => (
              <tr
                key={txn.id}
                onClick={() => onSelectTransaction && onSelectTransaction(txn)}
                className="hover:bg-fx-elevated/60 cursor-pointer transition-colors group"
              >
                <td className="py-3 px-2">
                  <span className="font-semibold text-fx-text group-hover:text-fx-teal transition-colors">
                    {txn.id}
                  </span>
                  <div className="text-[10px] text-fx-muted font-sans truncate max-w-[130px]">
                    {txn.merchantName}
                  </div>
                </td>
                <td className="py-3 px-2 text-fx-muted font-sans text-[11px]">
                  {formatDate(txn.date)}
                </td>
                <td className="py-3 px-2">
                  <span className="px-2 py-0.5 rounded bg-fx-elevated border border-fx-border text-[11px] font-medium text-fx-text">
                    {txn.currencyPair}
                  </span>
                </td>
                <td className="py-3 px-2 text-right font-medium text-fx-text">
                  {formatCurrency(txn.fromAmount, txn.fromCurrency)}
                </td>
                <td className="py-3 px-2 text-right">
                  <span
                    className={`font-semibold ${
                      txn.fxMarkupPercent > 3.0 ? 'text-rose-400' : txn.fxMarkupPercent < 1.6 ? 'text-fx-green' : 'text-fx-text'
                    }`}
                  >
                    +{formatPercent(txn.fxMarkupPercent)}
                  </span>
                  <div className="text-[10px] text-fx-muted">
                    -${txn.fxMarkupLoss.toFixed(2)}
                  </div>
                </td>
                <td className="py-3 px-2 text-center">
                  <StatusBadge status={txn.status} size="sm" />
                </td>
                <td className="py-3 px-2 text-right">
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      if (onSelectTransaction) onSelectTransaction(txn);
                    }}
                    className="p-1 rounded hover:bg-fx-elevated text-fx-muted hover:text-fx-teal transition-colors"
                    title="Audit breakdown"
                  >
                    <ArrowUpRight className="w-3.5 h-3.5" />
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};
