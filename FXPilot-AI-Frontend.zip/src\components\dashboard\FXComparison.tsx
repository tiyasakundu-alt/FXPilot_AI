import React, { useState } from 'react';
import { ArrowRight, Info, ShieldAlert, Sparkles, CheckCircle2 } from 'lucide-react';
import { formatCurrency, formatNumber, formatPercent } from '../../utils/formatters';
import { calculateQuote } from '../../data/mockData';
import { Link } from 'react-router-dom';

export const FXComparison: React.FC = () => {
  const [testAmount, setTestAmount] = useState<number>(5000);
  const quote = calculateQuote('USD', 'INR', testAmount);

  return (
    <div className="p-5 rounded-xl border border-fx-border bg-fx-card shadow-subtle flex flex-col justify-between">
      {/* Header */}
      <div className="flex items-center justify-between pb-3 border-b border-fx-border/60">
        <div>
          <div className="flex items-center space-x-2">
            <h3 className="text-sm font-semibold text-fx-text">FX Rate Comparison</h3>
            <span className="text-[10px] font-mono px-1.5 py-0.5 rounded bg-teal-500/10 text-fx-teal">
              USD → INR
            </span>
          </div>
          <p className="text-[11px] text-fx-muted mt-0.5">
            Mid-market benchmark vs PayPal quoted settlement
          </p>
        </div>

        <span className="text-[10px] font-mono text-fx-muted">
          Quote at: {quote.timestamp}
        </span>
      </div>

      {/* Main Comparative Cards Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 my-4">
        {/* Mid-Market Rate Card */}
        <div className="p-3.5 rounded-lg border border-fx-border bg-fx-elevated/40 flex flex-col justify-between">
          <div className="flex items-center justify-between">
            <span className="text-[11px] font-medium text-fx-muted uppercase tracking-wider">
              Mid-Market Reference
            </span>
            <span className="w-2 h-2 rounded-full bg-fx-teal" />
          </div>
          <div className="mt-2">
            <div className="text-xl font-bold font-mono text-fx-teal">
              1 USD = ₹{quote.midMarketRate.toFixed(4)}
            </div>
            <p className="text-[11px] text-fx-muted mt-0.5">Zero-markup interbank baseline</p>
          </div>
          <div className="mt-3 pt-2 border-t border-fx-border/60 text-[11px] flex justify-between">
            <span className="text-fx-muted">Gross Yield:</span>
            <span className="font-semibold text-fx-text">
              ₹{formatNumber(quote.convertedMidMarket)}
            </span>
          </div>
        </div>

        {/* PayPal Simulated Rate Card */}
        <div className="p-3.5 rounded-lg border border-fx-border bg-fx-elevated/40 flex flex-col justify-between">
          <div className="flex items-center justify-between">
            <span className="text-[11px] font-medium text-fx-muted uppercase tracking-wider">
              PayPal Quote (Simulated)
            </span>
            <span className="w-2 h-2 rounded-full bg-rose-400" />
          </div>
          <div className="mt-2">
            <div className="text-xl font-bold font-mono text-fx-text">
              1 USD = ₹{quote.providerRate.toFixed(4)}
            </div>
            <p className="text-[11px] text-rose-400 mt-0.5 font-medium">
              +{quote.markupPercent}% hidden retail spread
            </p>
          </div>
          <div className="mt-3 pt-2 border-t border-fx-border/60 text-[11px] flex justify-between">
            <span className="text-fx-muted">Net Received:</span>
            <span className="font-semibold text-fx-text">
              ₹{formatNumber(quote.convertedProvider)}
            </span>
          </div>
        </div>
      </div>

      {/* Difference & Estimated Cost Breakdown */}
      <div className="p-3.5 rounded-lg border border-rose-500/20 bg-rose-500/5 mb-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <ShieldAlert className="w-4 h-4 text-rose-400 shrink-0" />
            <span className="text-xs font-semibold text-fx-text">
              Effective Spread Loss on ${testAmount.toLocaleString()} USD
            </span>
          </div>
          <span className="text-sm font-bold font-mono text-rose-400">
            -₹{formatNumber(quote.differenceAmount)} (~${formatNumber(quote.markupAmount)} USD)
          </span>
        </div>
        <p className="text-[11px] text-fx-muted mt-1 leading-relaxed">
          The quoted exchange rate captures an effective difference of ₹{(quote.midMarketRate - quote.providerRate).toFixed(4)} per US Dollar converted.
        </p>
      </div>

      {/* Quick Amount Pill Presets */}
      <div className="flex items-center justify-between pt-2 border-t border-fx-border/60 text-xs">
        <div className="flex items-center space-x-1.5">
          <span className="text-[11px] text-fx-muted">Test Batch:</span>
          {[1000, 5000, 10000, 25000].map((amt) => (
            <button
              key={amt}
              onClick={() => setTestAmount(amt)}
              className={`px-2 py-0.5 rounded text-[11px] font-mono transition-colors ${
                testAmount === amt
                  ? 'bg-fx-teal text-black font-semibold'
                  : 'bg-fx-elevated text-fx-muted hover:text-fx-text'
              }`}
            >
              ${amt.toLocaleString()}
            </button>
          ))}
        </div>

        <Link
          to="/converter"
          className="inline-flex items-center space-x-1 text-xs text-fx-teal hover:underline font-medium"
        >
          <span>Full Converter</span>
          <ArrowRight className="w-3.5 h-3.5" />
        </Link>
      </div>
    </div>
  );
};
