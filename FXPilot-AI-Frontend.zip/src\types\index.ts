export type CurrencyCode = 'USD' | 'INR' | 'EUR' | 'GBP' | 'JPY' | 'AUD' | 'CAD' | 'SGD';

export interface Currency {
  code: CurrencyCode;
  name: string;
  symbol: string;
  flag: string;
  country: string;
  decimalPlaces: number;
}

export type TimePeriod = '1D' | '1W' | '1M' | '3M' | '1Y';

export interface RateHistoryPoint {
  date: string;
  time?: string;
  timestamp: number;
  midMarket: number;
  provider: number;
  spread: number;
  markupPercent: number;
  high: number;
  low: number;
}

export interface FXQuote {
  id: string;
  fromCurrency: CurrencyCode;
  toCurrency: CurrencyCode;
  amount: number;
  midMarketRate: number;
  providerRate: number;
  markupPercent: number;
  markupAmount: number;
  convertedMidMarket: number;
  convertedProvider: number;
  differenceAmount: number;
  timestamp: string;
  providerName: string;
  benchmarks: {
    wise: { rate: number; received: number; fee: number; markupPercent: number };
    bankWire: { rate: number; received: number; fee: number; markupPercent: number };
    stripe: { rate: number; received: number; fee: number; markupPercent: number };
  };
}

export type TransactionStatus = 'Optimized' | 'Standard' | 'High Markup' | 'Pending Review';

export interface Transaction {
  id: string;
  date: string;
  time: string;
  currencyPair: string;
  fromCurrency: CurrencyCode;
  toCurrency: CurrencyCode;
  fromAmount: number;
  toAmount: number;
  midMarketRate: number;
  providerRate: number;
  fxMarkupPercent: number;
  fxMarkupLoss: number;
  status: TransactionStatus;
  merchantName: string;
  paymentMethod: string;
  referenceId: string;
}

export interface ChatMessage {
  id: string;
  sender: 'user' | 'assistant';
  content: string;
  timestamp: string;
  analysis?: {
    pair: string;
    amount?: number;
    referenceRate: number;
    providerRate: number;
    markupPercent: number;
    markupLoss: number;
    recommendation: 'CONVERT NOW' | 'HOLD / WAIT' | 'HIGH SPREAD WARNING' | 'OPTIMIZE ROUTE';
    confidence: number;
    rationale: string;
  };
}

export interface UserSettings {
  theme: 'dark' | 'light';
  defaultBaseCurrency: CurrencyCode;
  defaultTargetCurrency: CurrencyCode;
  alertMarkupThreshold: number;
  emailAlerts: boolean;
  rateSpikeAlerts: boolean;
  dailyDigest: boolean;
  merchantName: string;
  businessEntity: string;
  apiKey: string;
  apiEnvironment: 'sandbox' | 'production';
}

export interface ToastMessage {
  id: string;
  type: 'success' | 'info' | 'warning' | 'error';
  title: string;
  message?: string;
  timestamp?: number;
}
