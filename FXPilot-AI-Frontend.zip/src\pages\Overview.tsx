import React, { useState } from 'react';
import { DollarSign, Percent, PiggyBank, FileCheck, ArrowUpRight, Sparkles, RefreshCw } from 'lucide-react';
import { StatCard } from '../components/dashboard/StatCard';
import { ExchangeRateChart } from '../components/dashboard/ExchangeRateChart';
import { FXComparison } from '../components/dashboard/FXComparison';
import { RecentTransactions } from '../components/dashboard/RecentTransactions';
import { AIInsight } from '../components/dashboard/AIInsight';
import { DemoBanner } from '../components/common/DemoBanner';
import { TransactionDetailDrawer } from '../components/transactions/TransactionDetailDrawer';
import { Transaction } from '../types';
import { useToast } from '../context/ToastContext';
import { Link } from 'react-router-dom';

export const Overview: React.FC = () => {
  const { addToast } = useToast();
  const [selectedTransaction, setSelectedTransaction] = useState<Transaction | null>(null);
  const [isRefreshing, setIsRefreshing] = useState(false);

  // Current formatted date
  const todayFormatted = new Intl.DateTimeFormat('en-US', {
    weekday: 'long',
    month: 'short',
    day: 'numeric',
    year: 'numeric',
  }).format(new Date());

  const handleSimulateSync = () => {
    setIsRefreshing(true);
    setTimeout(() => {
      setIsRefreshing(false);
      addToast({
        type: 'info',
        title: 'FX Feed Synchronized',
        message: 'Mid-market interbank quotes and PayPal simulated rates updated.',
      });
    }, 600);
  };

  return (
    <div className="space-y-6">
      {/* Top Banner Alert for Demo */}
      <DemoBanner variant="banner" />

      {/* Header Area */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center space-x-2">
            <h1 className="text-xl sm:text-2xl font-bold tracking-tight text-fx-text">
              Welcome back
            </h1>
            <span className="w-2 h-2 rounded-full bg-emerald-400" />
          </div>
          <p className="text-xs sm:text-sm text-fx-muted mt-0.5">
            Here's your cross-border FX overview for{' '}
            <span className="text-fx-text font-medium">{todayFormatted}</span>.
          </p>
        </div>

        {/* Action Controls */}
        <div className="flex items-center space-x-2.5">
          <button
            onClick={handleSimulateSync}
            className={`inline-flex items-center space-x-1.5 px-3 py-2 rounded-lg border border-fx-border bg-fx-card hover:bg-fx-elevated text-fx-muted hover:text-fx-text text-xs font-medium transition-colors ${
              isRefreshing ? 'opacity-70 pointer-events-none' : ''
            }`}
          >
            <RefreshCw className={`w-3.5 h-3.5 ${isRefreshing ? 'animate-spin text-fx-teal' : ''}`} />
            <span>Sync Live Feed</span>
          </button>

          <Link
            to="/converter"
            className="inline-flex items-center space-x-1.5 px-3.5 py-2 rounded-lg bg-fx-teal text-black text-xs font-semibold hover:opacity-90 transition-opacity shadow-sm"
          >
            <Sparkles className="w-3.5 h-3.5" />
            <span>Audit Conversion</span>
          </Link>
        </div>
      </div>

      {/* Four KPI Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* KPI 1: Total Transaction Volume */}
        <StatCard
          title="Total Transaction Volume"
          value="$128,450"
          change="+12.4%"
          isPositiveChange={true}
          changeLabel="vs last month"
          icon={DollarSign}
          tooltip="Total cross-border gross settlement volume tracked across all corridors."
        />

        {/* KPI 2: Average FX Markup */}
        <StatCard
          title="Average FX Markup"
          value="1.42%"
          change="-0.28%"
          isPositiveChange={true}
          changeLabel="spread compression"
          icon={Percent}
          tooltip="Weighted average margin charged above interbank mid-market rate."
        />

        {/* KPI 3: Potential Savings */}
        <StatCard
          title="Potential Savings"
          value="₹24,850"
          subtitle="Illustrative estimate based on mid-market vs provider quotes"
          icon={PiggyBank}
          tooltip="Estimated gross savings achievable through scheduled batch routing and wholesale corridors."
        />

        {/* KPI 4: Transactions Analysed */}
        <StatCard
          title="Transactions Analysed"
          value="248"
          change="+18"
          isPositiveChange={true}
          changeLabel="audited this week"
          icon={FileCheck}
          tooltip="Total number of international merchant invoices and gateway payouts audited."
        />
      </div>

      {/* Main Charts & Rate Comparison Section */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Historical USD/INR Chart (Takes 2 cols on desktop) */}
        <div className="lg:col-span-2">
          <ExchangeRateChart initialPair="USD/INR" />
        </div>

        {/* FX Rate Comparison Card (Takes 1 col on desktop) */}
        <div className="lg:col-span-1">
          <FXComparison />
        </div>
      </div>

      {/* Bottom Section: Recent Transactions & AI Tactical Insight */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Recent Transactions Table (Takes 2 cols) */}
        <div className="lg:col-span-2">
          <RecentTransactions onSelectTransaction={(txn) => setSelectedTransaction(txn)} />
        </div>

        {/* AI Insight Panel (Takes 1 col) */}
        <div className="lg:col-span-1">
          <AIInsight />
        </div>
      </div>

      {/* Transaction Detail Drawer */}
      <TransactionDetailDrawer
        transaction={selectedTransaction}
        onClose={() => setSelectedTransaction(null)}
      />
    </div>
  );
};
