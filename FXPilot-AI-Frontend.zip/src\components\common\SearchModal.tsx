import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { Search, X, ArrowRight, DollarSign, BarChart2, Bot, FileText, Settings, ArrowLeftRight } from 'lucide-react';
import { MOCK_TRANSACTIONS } from '../../data/mockData';

interface SearchModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const SearchModal: React.FC<SearchModalProps> = ({ isOpen, onClose }) => {
  const [query, setQuery] = useState('');
  const navigate = useNavigate();

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key === 'k') {
        e.preventDefault();
        if (isOpen) onClose();
        else setQuery('');
      }
      if (e.key === 'Escape' && isOpen) {
        onClose();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, onClose]);

  if (!isOpen) return null;

  const quickPages = [
    { title: 'Overview Dashboard', path: '/', icon: BarChart2, desc: 'Portfolio FX KPI and USD/INR chart' },
    { title: 'FX Converter', path: '/converter', icon: ArrowLeftRight, desc: 'Calculate spreads & compare provider quotes' },
    { title: 'FX Analytics', path: '/analytics', icon: DollarSign, desc: 'Historical volatility & markup trends' },
    { title: 'AI Agent', path: '/agent', icon: Bot, desc: 'Simulated institutional conversational assistant' },
    { title: 'Transactions History', path: '/transactions', icon: FileText, desc: 'Audited cross-border payment records' },
    { title: 'Settings', path: '/settings', icon: Settings, desc: 'Appearance, preferences & FastAPI hooks' },
  ];

  const filteredPages = quickPages.filter((p) =>
    p.title.toLowerCase().includes(query.toLowerCase()) || p.desc.toLowerCase().includes(query.toLowerCase())
  );

  const matchedTxns = query.trim()
    ? MOCK_TRANSACTIONS.filter(
        (t) =>
          t.id.toLowerCase().includes(query.toLowerCase()) ||
          t.merchantName.toLowerCase().includes(query.toLowerCase()) ||
          t.currencyPair.toLowerCase().includes(query.toLowerCase())
      ).slice(0, 4)
    : [];

  const handleSelect = (path: string) => {
    navigate(path);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-start justify-center pt-20 px-4 bg-black/60 backdrop-blur-sm animate-fadeIn">
      <div
        className="relative w-full max-w-xl bg-fx-card border border-fx-border rounded-xl shadow-2xl overflow-hidden"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Search Input Bar */}
        <div className="flex items-center px-4 py-3.5 border-b border-fx-border">
          <Search className="w-5 h-5 text-fx-teal mr-3 shrink-0" />
          <input
            type="text"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Search pages, currencies, transactions, or merchant names..."
            autoFocus
            className="w-full bg-transparent text-fx-text placeholder:text-fx-muted text-sm focus:outline-none"
          />
          {query && (
            <button
              onClick={() => setQuery('')}
              className="p-1 text-fx-muted hover:text-fx-text rounded"
            >
              <X className="w-4 h-4" />
            </button>
          )}
          <span className="ml-2 text-[10px] font-mono px-1.5 py-0.5 rounded border border-fx-border text-fx-muted">
            ESC
          </span>
        </div>

        {/* Search Results */}
        <div className="max-h-96 overflow-y-auto p-3 space-y-4">
          {/* Quick Pages */}
          <div>
            <p className="text-[11px] font-mono uppercase tracking-wider text-fx-muted px-2 mb-2">
              Navigation
            </p>
            <div className="space-y-1">
              {filteredPages.map((page) => {
                const Icon = page.icon;
                return (
                  <button
                    key={page.path}
                    onClick={() => handleSelect(page.path)}
                    className="w-full flex items-center justify-between p-2.5 rounded-lg hover:bg-fx-elevated text-left group transition-colors"
                  >
                    <div className="flex items-center space-x-3">
                      <div className="p-1.5 rounded-md bg-fx-elevated border border-fx-border group-hover:border-fx-teal text-fx-teal">
                        <Icon className="w-4 h-4" />
                      </div>
                      <div>
                        <p className="text-xs font-medium text-fx-text group-hover:text-fx-teal transition-colors">
                          {page.title}
                        </p>
                        <p className="text-[11px] text-fx-muted">{page.desc}</p>
                      </div>
                    </div>
                    <ArrowRight className="w-3.5 h-3.5 text-fx-muted opacity-0 group-hover:opacity-100 transition-opacity" />
                  </button>
                );
              })}
            </div>
          </div>

          {/* Transactions Match */}
          {matchedTxns.length > 0 && (
            <div>
              <p className="text-[11px] font-mono uppercase tracking-wider text-fx-muted px-2 mb-2">
                Matching Transactions
              </p>
              <div className="space-y-1">
                {matchedTxns.map((txn) => (
                  <button
                    key={txn.id}
                    onClick={() => handleSelect('/transactions')}
                    className="w-full flex items-center justify-between p-2.5 rounded-lg hover:bg-fx-elevated text-left group transition-colors"
                  >
                    <div>
                      <div className="flex items-center space-x-2">
                        <span className="font-mono text-xs font-semibold text-fx-text">{txn.id}</span>
                        <span className="text-[10px] px-1.5 py-0.2 rounded bg-fx-elevated text-fx-teal font-mono">
                          {txn.currencyPair}
                        </span>
                      </div>
                      <p className="text-[11px] text-fx-muted">{txn.merchantName}</p>
                    </div>
                    <div className="text-right">
                      <span className="text-xs font-medium text-fx-text">${txn.fromAmount.toLocaleString()}</span>
                      <p className="text-[10px] text-rose-400 font-mono">+{txn.fxMarkupPercent}% markup</p>
                    </div>
                  </button>
                ))}
              </div>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="p-2.5 border-t border-fx-border bg-fx-elevated/50 flex items-center justify-between text-[11px] text-fx-muted px-4">
          <span>Tip: Use ↑ ↓ to navigate, Enter to select</span>
          <span className="font-mono">FXPilot AI v1.0</span>
        </div>
      </div>
    </div>
  );
};
