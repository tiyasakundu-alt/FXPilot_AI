import React, { useState, useMemo } from 'react';
import {
  ResponsiveContainer,
  AreaChart,
  Area,
  XAxis,
  YAxis,
  Tooltip,
  CartesianGrid,
  ReferenceLine,
} from 'recharts';
import { TimePeriod } from '../../types';
import { generateRateHistory } from '../../data/mockData';
import { useTheme } from '../../context/ThemeContext';
import { TrendingUp, RefreshCw, BarChart2 } from 'lucide-react';

interface ExchangeRateChartProps {
  initialPair?: string;
}

export const ExchangeRateChart: React.FC<ExchangeRateChartProps> = ({ initialPair = 'USD/INR' }) => {
  const { theme } = useTheme();
  const [selectedPair, setSelectedPair] = useState<string>(initialPair);
  const [period, setPeriod] = useState<TimePeriod>('1M');
  const [isRefreshing, setIsRefreshing] = useState(false);

  const periods: TimePeriod[] = ['1D', '1W', '1M', '3M', '1Y'];
  const availablePairs = ['USD/INR', 'EUR/INR', 'GBP/INR', 'USD/EUR'];

  const data = useMemo(() => {
    return generateRateHistory(period, selectedPair);
  }, [period, selectedPair]);

  const latestPoint = data[data.length - 1];
  const firstPoint = data[0];
  const rateDiff = latestPoint && firstPoint ? latestPoint.midMarket - firstPoint.midMarket : 0;
  const percentDiff = firstPoint ? (rateDiff / firstPoint.midMarket) * 100 : 0;

  // Min and max for YAxis padding
  const { minRate, maxRate } = useMemo(() => {
    if (!data.length) return { minRate: 0, maxRate: 100 };
    const values = data.map((d) => d.midMarket);
    const min = Math.min(...values);
    const max = Math.max(...values);
    const pad = (max - min) * 0.15 || 0.5;
    return {
      minRate: Number((min - pad).toFixed(2)),
      maxRate: Number((max + pad).toFixed(2)),
    };
  }, [data]);

  const handleRefresh = () => {
    setIsRefreshing(true);
    setTimeout(() => {
      setIsRefreshing(false);
    }, 400);
  };

  // Styling based on active theme
  const isDark = theme === 'dark';
  const gridColor = isDark ? '#202C2A' : '#E2EAE7';
  const tickColor = isDark ? '#899795' : '#71817D';
  const tooltipBg = isDark ? '#101717' : '#FFFFFF';
  const tooltipBorder = isDark ? '#202C2A' : '#E2EAE7';
  const textColor = isDark ? '#F2F5F4' : '#172321';
  const primaryTeal = isDark ? '#19C3B1' : '#119E91';

  return (
    <div className="p-5 rounded-xl border border-fx-border bg-fx-card shadow-subtle flex flex-col justify-between">
      {/* Chart Header Bar */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-4 border-b border-fx-border/60">
        <div>
          <div className="flex items-center space-x-2">
            <span className="text-xs font-mono uppercase tracking-wider text-fx-muted">
              Exchange Rate Trajectory
            </span>
            <span className="text-[10px] font-mono px-1.5 py-0.2 rounded bg-fx-elevated text-fx-teal border border-fx-border">
              Mid-Market Reference
            </span>
          </div>

          <div className="mt-1 flex items-baseline space-x-3">
            <h2 className="text-xl sm:text-2xl font-bold font-mono tracking-tight text-fx-text">
              {latestPoint ? latestPoint.midMarket.toFixed(4) : '—'}
            </h2>
            <div
              className={`flex items-center text-xs font-mono font-medium ${
                rateDiff >= 0 ? 'text-fx-green' : 'text-fx-red'
              }`}
            >
              <span>{rateDiff >= 0 ? '+' : ''}{rateDiff.toFixed(4)} ({percentDiff.toFixed(2)}%)</span>
            </div>
            <span className="text-[11px] text-fx-muted hidden sm:inline">
              in {period} timeframe
            </span>
          </div>
        </div>

        {/* Pair selector and Period Selector */}
        <div className="flex flex-wrap items-center gap-2">
          {/* Pair Pills */}
          <div className="inline-flex rounded-lg border border-fx-border bg-fx-elevated/80 p-0.5">
            {availablePairs.map((pair) => (
              <button
                key={pair}
                onClick={() => setSelectedPair(pair)}
                className={`px-2.5 py-1 text-xs font-medium rounded-md transition-colors ${
                  selectedPair === pair
                    ? 'bg-fx-card text-fx-teal shadow-sm font-semibold'
                    : 'text-fx-muted hover:text-fx-text'
                }`}
              >
                {pair}
              </button>
            ))}
          </div>

          {/* Timeframe Buttons */}
          <div className="inline-flex rounded-lg border border-fx-border bg-fx-elevated/80 p-0.5">
            {periods.map((p) => (
              <button
                key={p}
                onClick={() => setPeriod(p)}
                className={`px-2 py-1 text-xs font-medium rounded-md transition-colors ${
                  period === p
                    ? 'bg-fx-teal text-black font-semibold shadow-sm'
                    : 'text-fx-muted hover:text-fx-text'
                }`}
              >
                {p}
              </button>
            ))}
          </div>

          {/* Refresh simulated feed */}
          <button
            onClick={handleRefresh}
            className={`p-1.5 rounded-lg border border-fx-border bg-fx-elevated text-fx-muted hover:text-fx-text transition-all ${
              isRefreshing ? 'animate-spin text-fx-teal' : ''
            }`}
            title="Refresh simulated live rates"
            aria-label="Refresh rate data"
          >
            <RefreshCw className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      {/* Chart Canvas */}
      <div className="h-72 w-full mt-4">
        <ResponsiveContainer width="100%" height="100%">
          <AreaChart data={data} margin={{ top: 10, right: 10, left: -10, bottom: 0 }}>
            <defs>
              <linearGradient id="tealGradient" x1="0" y1="0" x2="0" y2="1">
                <stop offset="5%" stopColor={primaryTeal} stopOpacity={0.25} />
                <stop offset="95%" stopColor={primaryTeal} stopOpacity={0.0} />
              </linearGradient>
            </defs>
            <CartesianGrid strokeDasharray="3 3" stroke={gridColor} vertical={false} />
            <XAxis
              dataKey="date"
              stroke={tickColor}
              fontSize={11}
              tickLine={false}
              axisLine={{ stroke: gridColor }}
            />
            <YAxis
              domain={[minRate, maxRate]}
              stroke={tickColor}
              fontSize={11}
              tickLine={false}
              axisLine={{ stroke: gridColor }}
              tickFormatter={(v) => v.toFixed(selectedPair.includes('JPY') ? 2 : 2)}
            />
            <Tooltip
              content={({ active, payload, label }) => {
                if (active && payload && payload.length) {
                  const pt = payload[0].payload;
                  return (
                    <div
                      style={{ backgroundColor: tooltipBg, borderColor: tooltipBorder }}
                      className="p-3 rounded-lg border shadow-xl text-xs font-mono space-y-1.5"
                    >
                      <div className="flex items-center justify-between border-b border-fx-border/60 pb-1 text-fx-muted">
                        <span>{label}</span>
                        <span className="text-[10px] text-fx-teal">{selectedPair}</span>
                      </div>
                      <div className="flex justify-between space-x-4">
                        <span className="text-fx-muted">Mid-Market:</span>
                        <span className="font-semibold text-fx-teal">{pt.midMarket}</span>
                      </div>
                      <div className="flex justify-between space-x-4">
                        <span className="text-fx-muted">PayPal Quoted:</span>
                        <span className="font-medium text-fx-text">{pt.provider}</span>
                      </div>
                      <div className="flex justify-between space-x-4 pt-1 border-t border-fx-border/40 text-[11px]">
                        <span className="text-fx-muted">Spread Markup:</span>
                        <span className="text-rose-400 font-semibold">+{pt.markupPercent}%</span>
                      </div>
                    </div>
                  );
                }
                return null;
              }}
            />
            <Area
              type="monotone"
              dataKey="midMarket"
              stroke={primaryTeal}
              strokeWidth={2}
              fillOpacity={1}
              fill="url(#tealGradient)"
            />
          </AreaChart>
        </ResponsiveContainer>
      </div>

      {/* Chart Footer Info */}
      <div className="mt-3 pt-3 border-t border-fx-border/60 flex flex-wrap items-center justify-between text-xs text-fx-muted gap-2">
        <div className="flex items-center space-x-4">
          <div className="flex items-center space-x-1.5">
            <span className="w-2 h-2 rounded-full bg-fx-teal" />
            <span className="text-[11px]">Mid-Market Rate</span>
          </div>
          <div className="flex items-center space-x-1.5">
            <span className="w-2 h-0.5 bg-rose-400" />
            <span className="text-[11px]">Avg Retail Spread: ~3.25%</span>
          </div>
        </div>
        <div className="text-[11px] font-mono text-fx-muted">
          High: <span className="text-fx-text font-medium">{latestPoint?.high ?? '—'}</span> | Low:{' '}
          <span className="text-fx-text font-medium">{latestPoint?.low ?? '—'}</span>
        </div>
      </div>
    </div>
  );
};
