import React, { useState } from 'react';
import { CurrencyCode, FXQuote } from '../types';
import { SUPPORTED_CURRENCIES, calculateQuote } from '../data/mockData';
import { CurrencySelector } from '../components/common/CurrencySelector';
import { DemoBanner } from '../components/common/DemoBanner';
import { formatCurrency, formatNumber, formatPercent } from '../utils/formatters';
import {
  ArrowLeftRight,
  Sparkles,
  ShieldAlert,
  CheckCircle2,
  TrendingDown,
  Info,
  Clock,
  Send,
  Building,
  Globe,
  DollarSign,
} from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { useToast } from '../context/ToastContext';

export const Converter: React.FC = () => {
  const navigate = useNavigate();
  const { addToast } = useToast();

  const [fromCurrency, setFromCurrency] = useState<CurrencyCode>('USD');
  const [toCurrency, setToCurrency] = useState<CurrencyCode>('INR');
  const [amount, setAmount] = useState<number>(5000);
  const [hasAnalysed, setHasAnalysed] = useState<boolean>(true);
  const [isSwapping, setIsSwapping] = useState<boolean>(false);

  const quote: FXQuote = calculateQuote(fromCurrency, toCurrency, amount);

  const handleSwap = () => {
    setIsSwapping(true);
    setTimeout(() => {
      setFromCurrency(toCurrency);
      setToCurrency(fromCurrency);
      setIsSwapping(false);
      addToast({
        type: 'info',
        title: 'Currencies Swapped',
        message: `Now converting from ${toCurrency} to ${fromCurrency}`,
      });
    }, 150);
  };

  const handleAnalyse = () => {
    setHasAnalysed(true);
    addToast({
      type: 'success',
      title: 'Spread Analysis Generated',
      message: `Audited ${amount} ${fromCurrency} → ${toCurrency} quote.`,
    });
  };

  const presetAmounts = [1000, 5000, 10000, 25000, 50000];

  return (
    <div className="space-y-6 max-w-5xl mx-auto">
      {/* Demo Banner */}
      <DemoBanner variant="banner" />

      {/* Page Header */}
      <div>
        <div className="flex items-center space-x-2">
          <h1 className="text-xl sm:text-2xl font-bold tracking-tight text-fx-text">
            Institutional FX Converter & Spread Auditor
          </h1>
        </div>
        <p className="text-xs sm:text-sm text-fx-muted mt-1">
          Compute zero-margin mid-market rates, expose simulated PayPal conversion spreads, and analyze hidden fees.
        </p>
      </div>

      {/* Main Converter Card */}
      <div className="p-6 rounded-2xl border border-fx-border bg-fx-card shadow-elevated">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-5 items-center">
          {/* Amount Input (Takes 5 cols) */}
          <div className="lg:col-span-4">
            <label className="block text-[11px] font-medium text-fx-muted uppercase tracking-wider mb-1.5">
              Transfer Amount
            </label>
            <div className="relative">
              <span className="absolute inset-y-0 left-0 pl-3.5 flex items-center text-fx-muted font-mono text-sm">
                {SUPPORTED_CURRENCIES.find((c) => c.code === fromCurrency)?.symbol || '$'}
              </span>
              <input
                type="number"
                min="1"
                step="any"
                value={amount}
                onChange={(e) => setAmount(Math.max(0, parseFloat(e.target.value) || 0))}
                className="w-full bg-fx-elevated text-fx-text border border-fx-border rounded-lg pl-8 pr-4 py-2.5 text-base font-semibold font-mono focus:outline-none focus:border-fx-teal focus:ring-1 focus:ring-fx-teal transition-colors"
                placeholder="0.00"
              />
            </div>
          </div>

          {/* From Currency (Takes 3 cols) */}
          <div className="lg:col-span-3">
            <CurrencySelector
              label="From Currency"
              value={fromCurrency}
              onChange={setFromCurrency}
              disabledCurrency={toCurrency}
            />
          </div>

          {/* Swap Button (Takes 1 col) */}
          <div className="lg:col-span-1 flex justify-center pt-5">
            <button
              onClick={handleSwap}
              type="button"
              className={`p-2.5 rounded-xl border border-fx-border bg-fx-elevated hover:bg-fx-card text-fx-muted hover:text-fx-teal transition-all ${
                isSwapping ? 'rotate-180 text-fx-teal' : ''
              }`}
              title="Swap Currencies"
              aria-label="Swap Currencies"
            >
              <ArrowLeftRight className="w-4 h-4" />
            </button>
          </div>

          {/* To Currency (Takes 4 cols) */}
          <div className="lg:col-span-4">
            <CurrencySelector
              label="To Currency"
              value={toCurrency}
              onChange={setToCurrency}
              disabledCurrency={fromCurrency}
            />
          </div>
        </div>

        {/* Quick Amount Presets */}
        <div className="mt-4 pt-3 border-t border-fx-border/60 flex flex-wrap items-center justify-between gap-2 text-xs">
          <div className="flex items-center space-x-1.5">
            <span className="text-[11px] text-fx-muted">Presets:</span>
            {presetAmounts.map((preset) => (
              <button
                key={preset}
                onClick={() => setAmount(preset)}
                className={`px-2.5 py-1 rounded-md text-[11px] font-mono transition-colors ${
                  amount === preset
                    ? 'bg-fx-teal text-black font-semibold'
                    : 'bg-fx-elevated text-fx-muted hover:text-fx-text'
                }`}
              >
                ${preset.toLocaleString()}
              </button>
            ))}
          </div>

          <span className="text-[11px] font-mono text-fx-muted">
            Live Interbank Feed Refreshed: {quote.timestamp}
          </span>
        </div>

        {/* Live Calculation Preview Banner */}
        <div className="mt-6 p-4 rounded-xl border border-fx-border bg-fx-elevated/40 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          <div>
            <span className="text-[11px] text-fx-muted block">Mid-Market Fair Value</span>
            <div className="text-xl font-bold font-mono text-fx-teal mt-0.5">
              {formatCurrency(quote.convertedMidMarket, toCurrency)}
            </div>
            <span className="text-[11px] font-mono text-fx-muted">
              Rate: 1 {fromCurrency} = {quote.midMarketRate.toFixed(4)} {toCurrency}
            </span>
          </div>

          <div>
            <span className="text-[11px] text-fx-muted block">PayPal Quoted Payout</span>
            <div className="text-xl font-bold font-mono text-fx-text mt-0.5">
              {formatCurrency(quote.convertedProvider, toCurrency)}
            </div>
            <span className="text-[11px] font-mono text-rose-400">
              Rate: 1 {fromCurrency} = {quote.providerRate.toFixed(4)} {toCurrency} (-{quote.markupPercent}%)
            </span>
          </div>

          <div className="sm:col-span-2 lg:col-span-1 border-t sm:border-t-0 sm:border-l border-fx-border sm:pl-4 pt-2 sm:pt-0">
            <span className="text-[11px] text-fx-muted block">Spread Difference (Cost)</span>
            <div className="text-xl font-bold font-mono text-rose-400 mt-0.5">
              -{formatCurrency(quote.differenceAmount, toCurrency)}
            </div>
            <span className="text-[11px] text-fx-muted font-mono">
              ~{formatCurrency(quote.markupAmount, fromCurrency)} lost to FX margin
            </span>
          </div>
        </div>

        {/* Action Button: Analyse Conversion */}
        <div className="mt-6 flex flex-col sm:flex-row items-center justify-between gap-4">
          <p className="text-[11px] text-fx-muted flex items-center space-x-1.5">
            <Info className="w-3.5 h-3.5 text-fx-teal shrink-0" />
            <span>Non-custodial calculation only. No payment or wire is initiated.</span>
          </p>

          <button
            onClick={handleAnalyse}
            className="w-full sm:w-auto px-6 py-3 rounded-xl bg-fx-teal text-black font-semibold text-sm hover:opacity-90 transition-opacity flex items-center justify-center space-x-2 shadow-glow-teal"
          >
            <Sparkles className="w-4 h-4" />
            <span>Analyse Conversion Breakdown</span>
          </button>
        </div>
      </div>

      {/* Detailed Conversion Breakdown Section (Appears after analysis) */}
      {hasAnalysed && (
        <div className="space-y-6 animate-fadeIn">
          {/* Section 1: Spread Waterfall & Cost Dissection */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="p-4 rounded-xl border border-fx-border bg-fx-card">
              <span className="text-[10px] font-mono uppercase tracking-wider text-fx-muted">
                Step 1: Gross Value
              </span>
              <h3 className="text-lg font-bold font-mono text-fx-text mt-1">
                {formatCurrency(quote.convertedMidMarket, toCurrency)}
              </h3>
              <p className="text-xs text-fx-muted mt-1 leading-relaxed">
                Total destination value if settled at true 0% interbank mid-market rate.
              </p>
            </div>

            <div className="p-4 rounded-xl border border-rose-500/25 bg-rose-500/5">
              <span className="text-[10px] font-mono uppercase tracking-wider text-rose-400">
                Step 2: Spread Deduction
              </span>
              <h3 className="text-lg font-bold font-mono text-rose-400 mt-1">
                -{formatCurrency(quote.differenceAmount, toCurrency)}
              </h3>
              <p className="text-xs text-fx-muted mt-1 leading-relaxed">
                Hidden margin extracted via the {quote.markupPercent}% rate discount.
              </p>
            </div>

            <div className="p-4 rounded-xl border border-teal-500/30 bg-teal-500/5">
              <span className="text-[10px] font-mono uppercase tracking-wider text-fx-teal">
                Step 3: Net Settlement
              </span>
              <h3 className="text-lg font-bold font-mono text-fx-teal mt-1">
                {formatCurrency(quote.convertedProvider, toCurrency)}
              </h3>
              <p className="text-xs text-fx-muted mt-1 leading-relaxed">
                Actual credited amount deposited into merchant bank balance.
              </p>
            </div>
          </div>

          {/* Section 2: Competitive Provider Benchmark Matrix */}
          <div className="p-6 rounded-2xl border border-fx-border bg-fx-card shadow-subtle">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-4 border-b border-fx-border/60 gap-2">
              <div>
                <h3 className="text-base font-semibold text-fx-text">
                  Competitive Provider Benchmark Matrix
                </h3>
                <p className="text-xs text-fx-muted mt-0.5">
                  How PayPal's conversion quote compares with alternative settlement routes
                </p>
              </div>

              <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-fx-elevated text-fx-teal border border-fx-border self-start sm:self-auto">
                Simulated Benchmarks
              </span>
            </div>

            <div className="overflow-x-auto mt-4">
              <table className="w-full text-left text-xs">
                <thead>
                  <tr className="border-b border-fx-border text-fx-muted uppercase tracking-wider text-[10px] font-mono">
                    <th className="py-3 px-3">Provider Route</th>
                    <th className="py-3 px-3">Quoted Exchange Rate</th>
                    <th className="py-3 px-3 text-right">Effective Markup</th>
                    <th className="py-3 px-3 text-right">Recipient Receives</th>
                    <th className="py-3 px-3 text-right">Net Savings vs PayPal</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-fx-border/40 font-mono">
                  {/* Mid-Market Base */}
                  <tr className="bg-teal-500/5 font-semibold">
                    <td className="py-3.5 px-3 flex items-center space-x-2">
                      <Globe className="w-4 h-4 text-fx-teal" />
                      <span className="text-fx-teal font-sans">Mid-Market (Fair Baseline)</span>
                    </td>
                    <td className="py-3.5 px-3 text-fx-teal">
                      1 {fromCurrency} = {quote.midMarketRate.toFixed(4)} {toCurrency}
                    </td>
                    <td className="py-3.5 px-3 text-right text-emerald-400">0.00%</td>
                    <td className="py-3.5 px-3 text-right text-fx-teal font-bold">
                      {formatCurrency(quote.convertedMidMarket, toCurrency)}
                    </td>
                    <td className="py-3.5 px-3 text-right text-emerald-400">
                      +{formatCurrency(quote.differenceAmount, toCurrency)}
                    </td>
                  </tr>

                  {/* PayPal */}
                  <tr className="border-l-2 border-rose-500">
                    <td className="py-3.5 px-3 flex items-center space-x-2">
                      <div className="w-4 h-4 rounded-full bg-blue-500/20 text-blue-400 flex items-center justify-center text-[10px] font-bold">
                        P
                      </div>
                      <span className="text-fx-text font-sans font-medium">PayPal Standard Quote</span>
                    </td>
                    <td className="py-3.5 px-3 text-fx-text">
                      1 {fromCurrency} = {quote.providerRate.toFixed(4)} {toCurrency}
                    </td>
                    <td className="py-3.5 px-3 text-right text-rose-400">
                      +{quote.markupPercent}%
                    </td>
                    <td className="py-3.5 px-3 text-right font-medium text-fx-text">
                      {formatCurrency(quote.convertedProvider, toCurrency)}
                    </td>
                    <td className="py-3.5 px-3 text-right text-fx-muted">— (Baseline)</td>
                  </tr>

                  {/* Wise / Modern Cross-border */}
                  <tr>
                    <td className="py-3.5 px-3 flex items-center space-x-2">
                      <div className="w-4 h-4 rounded-full bg-emerald-500/20 text-emerald-400 flex items-center justify-center text-[10px] font-bold">
                        W
                      </div>
                      <span className="text-fx-text font-sans font-medium">Wise / Multi-Currency</span>
                    </td>
                    <td className="py-3.5 px-3 text-fx-text">
                      1 {fromCurrency} = {quote.benchmarks.wise.rate.toFixed(4)} {toCurrency}
                    </td>
                    <td className="py-3.5 px-3 text-right text-emerald-400">+0.42%</td>
                    <td className="py-3.5 px-3 text-right text-fx-text">
                      {formatCurrency(quote.benchmarks.wise.received, toCurrency)}
                    </td>
                    <td className="py-3.5 px-3 text-right text-emerald-400 font-bold">
                      +{formatCurrency(quote.benchmarks.wise.received - quote.convertedProvider, toCurrency)}
                    </td>
                  </tr>

                  {/* Traditional Bank Wire */}
                  <tr>
                    <td className="py-3.5 px-3 flex items-center space-x-2">
                      <Building className="w-4 h-4 text-fx-muted" />
                      <span className="text-fx-text font-sans font-medium">Traditional Bank Wire</span>
                    </td>
                    <td className="py-3.5 px-3 text-fx-text">
                      1 {fromCurrency} = {quote.benchmarks.bankWire.rate.toFixed(4)} {toCurrency}
                    </td>
                    <td className="py-3.5 px-3 text-right text-fx-muted">+2.45%</td>
                    <td className="py-3.5 px-3 text-right text-fx-text">
                      {formatCurrency(quote.benchmarks.bankWire.received, toCurrency)}
                    </td>
                    <td className="py-3.5 px-3 text-right text-emerald-400">
                      +{formatCurrency(quote.benchmarks.bankWire.received - quote.convertedProvider, toCurrency)}
                    </td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>

          {/* Section 3: AI Copilot Prompt CTA */}
          <div className="p-5 rounded-xl border border-teal-500/30 bg-fx-card flex flex-col sm:flex-row items-center justify-between gap-4">
            <div className="flex items-center space-x-3">
              <div className="p-2.5 rounded-xl bg-teal-500/10 border border-teal-500/30 text-fx-teal">
                <Sparkles className="w-5 h-5" />
              </div>
              <div>
                <h4 className="text-sm font-semibold text-fx-text">
                  Consult FXPilot AI Agent for this conversion
                </h4>
                <p className="text-xs text-fx-muted mt-0.5">
                  Ask our conversational model about optimal timing windows, weekend spread avoidance, and settlement routes.
                </p>
              </div>
            </div>

            <button
              onClick={() => navigate('/agent')}
              className="px-4 py-2 rounded-lg bg-teal-500/15 hover:bg-teal-500/25 border border-teal-500/30 text-fx-teal text-xs font-semibold flex items-center space-x-1.5 transition-colors shrink-0"
            >
              <span>Ask AI Agent</span>
              <Send className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
