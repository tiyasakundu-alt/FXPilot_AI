import React, { useState } from 'react';
import { Transaction } from '../../types';
import { StatusBadge } from '../common/StatusBadge';
import { formatCurrency, formatDate, formatPercent, formatNumber } from '../../utils/formatters';
import { X, Copy, ExternalLink, ShieldCheck, ArrowRight, Code, FileText, Check } from 'lucide-react';
import { useToast } from '../../context/ToastContext';

interface TransactionDetailDrawerProps {
  transaction: Transaction | null;
  onClose: () => void;
}

export const TransactionDetailDrawer: React.FC<TransactionDetailDrawerProps> = ({
  transaction,
  onClose,
}) => {
  const { addToast } = useToast();
  const [activeTab, setActiveTab] = useState<'audit' | 'json'>('audit');
  const [copied, setCopied] = useState(false);

  if (!transaction) return null;

  const handleCopy = (text: string, label: string) => {
    navigator.clipboard.writeText(text);
    setCopied(true);
    addToast({
      type: 'success',
      title: 'Copied to Clipboard',
      message: `${label} copied successfully.`,
    });
    setTimeout(() => setCopied(false), 2000);
  };

  const midYield = transaction.fromAmount * transaction.midMarketRate;
  const spreadDifference = midYield - transaction.toAmount;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-end bg-black/60 backdrop-blur-sm animate-fadeIn">
      {/* Click outside to close */}
      <div className="absolute inset-0" onClick={onClose} />

      {/* Drawer Container */}
      <div
        className="relative w-full max-w-lg h-full bg-fx-card border-l border-fx-border shadow-2xl flex flex-col z-10 overflow-hidden"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="p-5 border-b border-fx-border flex items-center justify-between bg-fx-elevated/40">
          <div>
            <div className="flex items-center space-x-2">
              <span className="text-xs font-mono font-bold text-fx-text">{transaction.id}</span>
              <StatusBadge status={transaction.status} size="sm" />
            </div>
            <p className="text-[11px] text-fx-muted mt-0.5">
              Audited on {formatDate(transaction.date)} at {transaction.time}
            </p>
          </div>

          <div className="flex items-center space-x-2">
            <button
              onClick={() => handleCopy(JSON.stringify(transaction, null, 2), 'Audit Record')}
              className="p-1.5 rounded-lg border border-fx-border hover:bg-fx-elevated text-fx-muted hover:text-fx-text transition-colors"
              title="Copy Record JSON"
            >
              {copied ? <Check className="w-4 h-4 text-fx-teal" /> : <Copy className="w-4 h-4" />}
            </button>
            <button
              onClick={onClose}
              className="p-1.5 rounded-lg border border-fx-border hover:bg-fx-elevated text-fx-muted hover:text-fx-text transition-colors"
              aria-label="Close drawer"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Tab switcher */}
        <div className="px-5 pt-3 border-b border-fx-border flex space-x-4">
          <button
            onClick={() => setActiveTab('audit')}
            className={`pb-2.5 text-xs font-medium border-b-2 flex items-center space-x-1.5 transition-colors ${
              activeTab === 'audit'
                ? 'border-fx-teal text-fx-teal'
                : 'border-transparent text-fx-muted hover:text-fx-text'
            }`}
          >
            <FileText className="w-3.5 h-3.5" />
            <span>FX Audit Report</span>
          </button>
          <button
            onClick={() => setActiveTab('json')}
            className={`pb-2.5 text-xs font-medium border-b-2 flex items-center space-x-1.5 transition-colors ${
              activeTab === 'json'
                ? 'border-fx-teal text-fx-teal'
                : 'border-transparent text-fx-muted hover:text-fx-text'
            }`}
          >
            <Code className="w-3.5 h-3.5" />
            <span>Raw Audit Payload</span>
          </button>
        </div>

        {/* Drawer Body */}
        <div className="flex-1 overflow-y-auto p-5 space-y-5">
          {activeTab === 'audit' ? (
            <>
              {/* Currency Conversion Flow Banner */}
              <div className="p-4 rounded-xl border border-fx-border bg-fx-elevated/40 flex items-center justify-between">
                <div>
                  <span className="text-[10px] uppercase font-mono text-fx-muted">Sent Amount</span>
                  <div className="text-lg font-bold font-mono text-fx-text">
                    {formatCurrency(transaction.fromAmount, transaction.fromCurrency)}
                  </div>
                </div>

                <div className="p-2 rounded-full bg-fx-card border border-fx-border text-fx-teal">
                  <ArrowRight className="w-4 h-4" />
                </div>

                <div className="text-right">
                  <span className="text-[10px] uppercase font-mono text-fx-muted">Settled Amount</span>
                  <div className="text-lg font-bold font-mono text-fx-teal">
                    {formatCurrency(transaction.toAmount, transaction.toCurrency)}
                  </div>
                </div>
              </div>

              {/* Spread & Markup Breakdown */}
              <div className="space-y-2.5">
                <h4 className="text-xs font-mono uppercase tracking-wider text-fx-muted">
                  Conversion Spread Breakdown
                </h4>

                <div className="p-4 rounded-xl border border-fx-border bg-fx-card space-y-3 text-xs font-mono">
                  <div className="flex justify-between items-center">
                    <span className="text-fx-muted">Mid-Market Rate (Zero Margin):</span>
                    <span className="font-semibold text-fx-text">
                      1 {transaction.fromCurrency} = {transaction.midMarketRate.toFixed(4)} {transaction.toCurrency}
                    </span>
                  </div>

                  <div className="flex justify-between items-center">
                    <span className="text-fx-muted">Provider Quoted Rate:</span>
                    <span className="font-semibold text-rose-400">
                      1 {transaction.fromCurrency} = {transaction.providerRate.toFixed(4)} {transaction.toCurrency}
                    </span>
                  </div>

                  <div className="flex justify-between items-center pt-2 border-t border-fx-border/50">
                    <span className="text-fx-muted">Spread Difference per unit:</span>
                    <span className="text-fx-text">
                      {(transaction.midMarketRate - transaction.providerRate).toFixed(4)} {transaction.toCurrency}
                    </span>
                  </div>

                  <div className="flex justify-between items-center">
                    <span className="text-fx-muted">Retail FX Markup:</span>
                    <span className="font-bold text-rose-400">
                      +{formatPercent(transaction.fxMarkupPercent)}
                    </span>
                  </div>

                  <div className="flex justify-between items-center pt-2 border-t border-fx-border/50 bg-rose-500/5 -mx-4 px-4 py-2 rounded-b-lg">
                    <span className="font-sans font-semibold text-fx-text">
                      Estimated Margin Leakage:
                    </span>
                    <span className="font-bold text-rose-400">
                      -${transaction.fxMarkupLoss.toFixed(2)} USD (~{formatCurrency(spreadDifference, transaction.toCurrency)})
                    </span>
                  </div>
                </div>
              </div>

              {/* Transaction Metadata */}
              <div className="space-y-2.5">
                <h4 className="text-xs font-mono uppercase tracking-wider text-fx-muted">
                  Settlement Details
                </h4>

                <div className="p-3.5 rounded-xl border border-fx-border bg-fx-card divide-y divide-fx-border/60 text-xs">
                  <div className="flex justify-between py-2">
                    <span className="text-fx-muted">Merchant Entity:</span>
                    <span className="font-medium text-fx-text">{transaction.merchantName}</span>
                  </div>
                  <div className="flex justify-between py-2">
                    <span className="text-fx-muted">Payment Channel:</span>
                    <span className="font-medium text-fx-text">{transaction.paymentMethod}</span>
                  </div>
                  <div className="flex justify-between py-2">
                    <span className="text-fx-muted">Provider Reference ID:</span>
                    <span className="font-mono text-fx-teal">{transaction.referenceId}</span>
                  </div>
                  <div className="flex justify-between py-2">
                    <span className="text-fx-muted">Audit Verification:</span>
                    <span className="inline-flex items-center text-emerald-400 space-x-1">
                      <ShieldCheck className="w-3.5 h-3.5" />
                      <span>Verified by FXPilot</span>
                    </span>
                  </div>
                </div>
              </div>

              {/* Benchmarking Comparison Card */}
              <div className="p-3.5 rounded-xl border border-teal-500/20 bg-teal-500/5 text-xs">
                <span className="font-semibold text-fx-text block">
                  FXPilot Route Optimization Note
                </span>
                <p className="text-[11px] text-fx-muted mt-1 leading-relaxed">
                  Consolidating this invoice into your weekly batch transfer could have saved approx{' '}
                  <strong className="text-emerald-400">${(transaction.fxMarkupLoss * 0.72).toFixed(2)} USD</strong>{' '}
                  by qualifying for wholesale tier spread limits.
                </p>
              </div>
            </>
          ) : (
            <div className="relative">
              <pre className="p-4 rounded-xl bg-fx-elevated border border-fx-border text-fx-text text-[11px] font-mono overflow-x-auto leading-relaxed">
                {JSON.stringify(transaction, null, 2)}
              </pre>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="p-4 border-t border-fx-border bg-fx-elevated/40 flex items-center justify-between">
          <span className="text-[11px] text-fx-muted font-mono">
            FastAPI Audit Stream Ready
          </span>
          <button
            onClick={onClose}
            className="px-4 py-2 rounded-lg bg-fx-teal text-black text-xs font-semibold hover:opacity-90 transition-opacity"
          >
            Close Audit
          </button>
        </div>
      </div>
    </div>
  );
};
