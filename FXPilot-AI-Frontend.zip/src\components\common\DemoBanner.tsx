import React from 'react';
import { Sparkles, Info } from 'lucide-react';

interface DemoBadgeProps {
  className?: string;
  variant?: 'badge' | 'banner';
}

export const DemoBanner: React.FC<DemoBadgeProps> = ({ className = '', variant = 'badge' }) => {
  if (variant === 'banner') {
    return (
      <div
        className={`flex items-center justify-between px-3.5 py-2 rounded-lg bg-teal-500/10 border border-teal-500/20 text-xs text-fx-muted ${className}`}
      >
        <div className="flex items-center space-x-2">
          <Sparkles className="w-3.5 h-3.5 text-fx-teal shrink-0" />
          <span>
            <strong className="text-fx-teal font-medium">DEMO ENVIRONMENT:</strong> Exchange rates, PayPal quotes, and AI agent insights are simulated models designed for testing.
          </span>
        </div>
        <span className="text-[10px] uppercase font-mono px-1.5 py-0.5 rounded bg-teal-500/15 text-fx-teal">
          Mock V1.0
        </span>
      </div>
    );
  }

  return (
    <div
      className={`inline-flex items-center space-x-1.5 px-2 py-0.5 rounded-full bg-teal-500/10 border border-teal-500/20 text-[10px] font-mono tracking-wider text-fx-teal ${className}`}
      title="This application is currently powered by realistic financial simulation models."
    >
      <span className="w-1.5 h-1.5 rounded-full bg-fx-teal animate-pulse" />
      <span>DEMO DATA</span>
    </div>
  );
};
