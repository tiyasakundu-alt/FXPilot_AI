import React, { useState, useMemo } from 'react';
import { Transaction, TransactionStatus } from '../types';
import { MOCK_TRANSACTIONS } from '../data/mockData';
import { StatusBadge } from '../components/common/StatusBadge';
import { TransactionDetailDrawer } from '../components/transactions/TransactionDetailDrawer';
import { DemoBanner } from '../components/common/DemoBanner';
import { formatCurrency, formatDate, formatPercent, downloadCSV } from '../utils/formatters';
import {
  Search,
  Filter,
  Download,
  Calendar,
  ArrowUpDown,
  ArrowUpRight,
  ChevronLeft,
  ChevronRight,
  ShieldCheck,
  Percent,
  DollarSign,
} from 'lucide-react';
import { useToast } from '../context/ToastContext';

export const Transactions: React.FC = () => {
  const { addToast } = useToast();
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedPair, setSelectedPair] = useState<string>('ALL');
  const [selectedStatus, setSelectedStatus] = useState<string>('ALL');
  const [selectedTransaction, setSelectedTransaction] = useState<Transaction | null>(null);
  const [currentPage, setCurrentPage] = useState(1);
  const itemsPerPage = 8;

  // Filter transactions
  const filteredTransactions = useMemo(() => {
    return MOCK_TRANSACTIONS.filter((txn) => {
      const matchesSearch =
        txn.id.toLowerCase().includes(searchQuery.toLowerCase()) ||
        txn.merchantName.toLowerCase().includes(searchQuery.toLowerCase()) ||
        txn.referenceId.toLowerCase().includes(searchQuery.toLowerCase());

      const matchesPair = selectedPair === 'ALL' || txn.currencyPair === selectedPair;
      const matchesStatus = selectedStatus === 'ALL' || txn.status === selectedStatus;

      return matchesSearch && matchesPair && matchesStatus;
    });
  }, [searchQuery, selectedPair, selectedStatus]);

  // Pagination
  const totalPages = Math.ceil(filteredTransactions.length / itemsPerPage) || 1;
  const paginatedTransactions = filteredTransactions.slice(
    (currentPage - 1) * itemsPerPage,
    currentPage * itemsPerPage
  );

  // Aggregate stats for filtered view
  const totalVolume = filteredTransactions.reduce((acc, t) => acc + t.fromAmount, 0);
  const totalMarkupLoss = filteredTransactions.reduce((acc, t) => acc + t.fxMarkupLoss, 0);
  const avgMarkup = filteredTransactions.length
    ? filteredTransactions.reduce((acc, t) => acc + t.fxMarkupPercent, 0) / filteredTransactions.length
    : 0;

  const handleExportCSV = () => {
    downloadCSV(filteredTransactions, `FXPilot-Transactions-${new Date().toISOString().slice(0, 10)}`);
    addToast({
      type: 'success',
      title: 'CSV Export Generated',
      message: `Exported ${filteredTransactions.length} transaction records.`,
    });
  };

  const currencyPairs = ['ALL', 'USD/INR', 'EUR/INR', 'GBP/INR', 'USD/EUR', 'AUD/INR', 'CAD/INR', 'SGD/INR'];
  const statuses: ('ALL' | TransactionStatus)[] = ['ALL', 'Optimized', 'Standard', 'High Markup', 'Pending Review'];

  return (
    <div className="space-y-6">
      <DemoBanner variant="banner" />

      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl sm:text-2xl font-bold tracking-tight text-fx-text">
            Cross-Border Transactions Audit
          </h1>
          <p className="text-xs sm:text-sm text-fx-muted mt-0.5">
            Full ledger of historical merchant payouts, PayPal quotes, and verified spread leakages.
          </p>
        </div>

        <button
          onClick={handleExportCSV}
          className="self-start sm:self-auto inline-flex items-center space-x-2 px-3.5 py-2 rounded-lg border border-fx-border bg-fx-card hover:bg-fx-elevated text-fx-text text-xs font-medium transition-colors shadow-sm"
        >
          <Download className="w-3.5 h-3.5 text-fx-teal" />
          <span>Export CSV Ledger</span>
        </button>
      </div>

      {/* Mini Summary Stats Bar */}
      <div className="grid grid-cols-1 sm:grid-cols-4 gap-4">
        <div className="p-3.5 rounded-xl border border-fx-border bg-fx-card">
          <span className="text-[10px] font-mono uppercase tracking-wider text-fx-muted">Records Filtered</span>
          <div className="text-xl font-bold font-mono text-fx-text mt-0.5">
            {filteredTransactions.length} <span className="text-xs text-fx-muted">of {MOCK_TRANSACTIONS.length}</span>
          </div>
        </div>

        <div className="p-3.5 rounded-xl border border-fx-border bg-fx-card">
          <span className="text-[10px] font-mono uppercase tracking-wider text-fx-muted">Filtered Volume</span>
          <div className="text-xl font-bold font-mono text-fx-teal mt-0.5">
            ${totalVolume.toLocaleString()}
          </div>
        </div>

        <div className="p-3.5 rounded-xl border border-fx-border bg-fx-card">
          <span className="text-[10px] font-mono uppercase tracking-wider text-fx-muted">Avg FX Markup</span>
          <div className="text-xl font-bold font-mono text-fx-text mt-0.5">
            {avgMarkup.toFixed(2)}%
          </div>
        </div>

        <div className="p-3.5 rounded-xl border border-rose-500/20 bg-rose-500/5">
          <span className="text-[10px] font-mono uppercase tracking-wider text-rose-400">Total Spread Cost</span>
          <div className="text-xl font-bold font-mono text-rose-400 mt-0.5">
            -${totalMarkupLoss.toFixed(2)} USD
          </div>
        </div>
      </div>

      {/* Filter and Search Bar */}
      <div className="p-4 rounded-xl border border-fx-border bg-fx-card shadow-subtle flex flex-col md:flex-row items-center justify-between gap-3">
        {/* Search Input */}
        <div className="relative w-full md:w-80">
          <Search className="w-4 h-4 text-fx-muted absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => {
              setSearchQuery(e.target.value);
              setCurrentPage(1);
            }}
            placeholder="Search by ID, merchant or ref..."
            className="w-full bg-fx-elevated text-fx-text text-xs placeholder:text-fx-muted pl-9 pr-4 py-2 border border-fx-border rounded-lg focus:outline-none focus:border-fx-teal focus:ring-1 focus:ring-fx-teal transition-colors"
          />
        </div>

        {/* Dropdowns */}
        <div className="flex flex-wrap items-center gap-2.5 w-full md:w-auto">
          {/* Pair filter */}
          <div className="flex items-center space-x-1.5 text-xs text-fx-muted">
            <span>Pair:</span>
            <select
              value={selectedPair}
              onChange={(e) => {
                setSelectedPair(e.target.value);
                setCurrentPage(1);
              }}
              className="bg-fx-elevated text-fx-text border border-fx-border rounded-lg px-2.5 py-1.5 text-xs focus:outline-none focus:border-fx-teal cursor-pointer"
            >
              {currencyPairs.map((p) => (
                <option key={p} value={p}>
                  {p}
                </option>
              ))}
            </select>
          </div>

          {/* Status filter */}
          <div className="flex items-center space-x-1.5 text-xs text-fx-muted">
            <span>Status:</span>
            <select
              value={selectedStatus}
              onChange={(e) => {
                setSelectedStatus(e.target.value);
                setCurrentPage(1);
              }}
              className="bg-fx-elevated text-fx-text border border-fx-border rounded-lg px-2.5 py-1.5 text-xs focus:outline-none focus:border-fx-teal cursor-pointer"
            >
              {statuses.map((s) => (
                <option key={s} value={s}>
                  {s}
                </option>
              ))}
            </select>
          </div>
        </div>
      </div>

      {/* Main Transactions Table */}
      <div className="rounded-xl border border-fx-border bg-fx-card shadow-subtle overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead>
              <tr className="border-b border-fx-border bg-fx-elevated/40 text-fx-muted uppercase tracking-wider text-[10px] font-mono">
                <th className="py-3 px-4">Transaction Details</th>
                <th className="py-3 px-3">Date & Time</th>
                <th className="py-3 px-3">Corridor</th>
                <th className="py-3 px-3 text-right">Sent Amount</th>
                <th className="py-3 px-3 text-right">Settled Amount</th>
                <th className="py-3 px-3 text-right">FX Markup %</th>
                <th className="py-3 px-3 text-right">Est. Loss</th>
                <th className="py-3 px-3 text-center">Status</th>
                <th className="py-3 px-4 text-right">Audit</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-fx-border/40 font-mono">
              {paginatedTransactions.length > 0 ? (
                paginatedTransactions.map((txn) => (
                  <tr
                    key={txn.id}
                    onClick={() => setSelectedTransaction(txn)}
                    className="hover:bg-fx-elevated/60 cursor-pointer transition-colors group"
                  >
                    <td className="py-3.5 px-4">
                      <span className="font-semibold text-fx-text group-hover:text-fx-teal transition-colors">
                        {txn.id}
                      </span>
                      <p className="text-[11px] text-fx-muted font-sans truncate max-w-[150px]">
                        {txn.merchantName}
                      </p>
                    </td>

                    <td className="py-3.5 px-3 text-fx-muted font-sans text-[11px]">
                      {formatDate(txn.date)}
                      <span className="block text-[10px] font-mono text-fx-muted/80">{txn.time}</span>
                    </td>

                    <td className="py-3.5 px-3">
                      <span className="px-2 py-0.5 rounded bg-fx-elevated border border-fx-border text-[11px] font-medium text-fx-text">
                        {txn.currencyPair}
                      </span>
                    </td>

                    <td className="py-3.5 px-3 text-right font-medium text-fx-text">
                      {formatCurrency(txn.fromAmount, txn.fromCurrency)}
                    </td>

                    <td className="py-3.5 px-3 text-right font-medium text-fx-teal">
                      {formatCurrency(txn.toAmount, txn.toCurrency)}
                    </td>

                    <td className="py-3.5 px-3 text-right">
                      <span
                        className={`font-semibold ${
                          txn.fxMarkupPercent > 3.0
                            ? 'text-rose-400'
                            : txn.fxMarkupPercent < 1.6
                            ? 'text-fx-green'
                            : 'text-fx-text'
                        }`}
                      >
                        +{formatPercent(txn.fxMarkupPercent)}
                      </span>
                    </td>

                    <td className="py-3.5 px-3 text-right text-rose-400 font-medium">
                      -${txn.fxMarkupLoss.toFixed(2)}
                    </td>

                    <td className="py-3.5 px-3 text-center">
                      <StatusBadge status={txn.status} size="sm" />
                    </td>

                    <td className="py-3.5 px-4 text-right">
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          setSelectedTransaction(txn);
                        }}
                        className="p-1 rounded-md hover:bg-fx-elevated text-fx-muted hover:text-fx-teal transition-colors"
                        title="Audit full breakdown"
                      >
                        <ArrowUpRight className="w-4 h-4" />
                      </button>
                    </td>
                  </tr>
                ))
              ) : (
                <tr>
                  <td colSpan={9} className="py-12 text-center text-fx-muted text-xs font-sans">
                    No transactions match your search and filter criteria.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>

        {/* Pagination Footer */}
        <div className="p-4 border-t border-fx-border flex items-center justify-between text-xs text-fx-muted">
          <span>
            Showing {(currentPage - 1) * itemsPerPage + 1} to{' '}
            {Math.min(currentPage * itemsPerPage, filteredTransactions.length)} of{' '}
            {filteredTransactions.length} records
          </span>

          <div className="flex items-center space-x-1.5">
            <button
              onClick={() => setCurrentPage((p) => Math.max(1, p - 1))}
              disabled={currentPage === 1}
              className="p-1.5 rounded-lg border border-fx-border hover:bg-fx-elevated disabled:opacity-30 disabled:pointer-events-none transition-colors"
            >
              <ChevronLeft className="w-4 h-4" />
            </button>
            <span className="px-2 font-mono">
              Page {currentPage} of {totalPages}
            </span>
            <button
              onClick={() => setCurrentPage((p) => Math.min(totalPages, p + 1))}
              disabled={currentPage === totalPages}
              className="p-1.5 rounded-lg border border-fx-border hover:bg-fx-elevated disabled:opacity-30 disabled:pointer-events-none transition-colors"
            >
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>

      {/* Transaction Details Modal */}
      <TransactionDetailDrawer
        transaction={selectedTransaction}
        onClose={() => setSelectedTransaction(null)}
      />
    </div>
  );
};
