import React from 'react';
import { CurrencyCode, Currency } from '../../types';
import { SUPPORTED_CURRENCIES } from '../../data/mockData';
import { ChevronDown } from 'lucide-react';

interface CurrencySelectorProps {
  value: CurrencyCode;
  onChange: (value: CurrencyCode) => void;
  disabledCurrency?: CurrencyCode;
  label?: string;
}

export const CurrencySelector: React.FC<CurrencySelectorProps> = ({
  value,
  onChange,
  disabledCurrency,
  label,
}) => {
  const selected = SUPPORTED_CURRENCIES.find((c) => c.code === value) || SUPPORTED_CURRENCIES[0];

  return (
    <div className="relative inline-block w-full">
      {label && (
        <label className="block text-[11px] font-medium text-fx-muted uppercase tracking-wider mb-1.5">
          {label}
        </label>
      )}
      <div className="relative">
        <select
          value={value}
          onChange={(e) => onChange(e.target.value as CurrencyCode)}
          className="w-full appearance-none bg-fx-elevated text-fx-text border border-fx-border rounded-lg pl-3 pr-9 py-2.5 text-sm font-medium focus:outline-none focus:border-fx-teal focus:ring-1 focus:ring-fx-teal cursor-pointer transition-colors"
        >
          {SUPPORTED_CURRENCIES.map((currency) => (
            <option
              key={currency.code}
              value={currency.code}
              disabled={currency.code === disabledCurrency}
              className="bg-fx-card text-fx-text"
            >
              {currency.flag} {currency.code} — {currency.name} ({currency.symbol})
            </option>
          ))}
        </select>
        <div className="pointer-events-none absolute inset-y-0 right-0 flex items-center px-2.5 text-fx-muted">
          <ChevronDown className="w-4 h-4" />
        </div>
      </div>
    </div>
  );
};
