import React, { useState, useMemo } from 'react';
import {
  ResponsiveContainer,
  ComposedChart,
  Area,
  Line,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  CartesianGrid,
  Legend,
} from 'recharts';
import { TimePeriod } from '../types';
import { generateRateHistory } from '../data/mockData';
import { DemoBanner } from '../components/common/DemoBanner';
import { useTheme } from '../context/ThemeContext';
import { formatCurrency, formatNumber, formatPercent } from '../utils/formatters';
import {
  LineChart as LineChartIcon,
  BarChart3,
  TrendingDown,
  Percent,
  Calendar,
  Layers,
  Sparkles,
  Calculator,
  ShieldCheck,
  AlertTriangle,
} from 'lucide-react';

export const Analytics: React.FC = () => {
  const { theme } = useTheme();
  const [selectedPair, setSelectedPair] = useState<string>('USD/INR');
  const [period, setPeriod] = useState<TimePeriod>('3M');
  const [annualVolume, setAnnualVolume] = useState<number>(250000);

  const availablePairs = ['USD/INR', 'EUR/INR', 'GBP/INR', 'USD/EUR', 'AUD/INR'];
  const periods: TimePeriod[] = ['1W', '1M', '3M', '1Y'];

  const rateHistory = useMemo(() => {
    return generateRateHistory(period, selectedPair);
  }, [period, selectedPair]);

  // Monthly markup history for Bar Chart
  const markupMonthlyTrend = [
    { month: 'Jun', avgMarkup: 3.45, optimizedMarkup: 1.65, volume: 18500 },
    { month: 'Jul', avgMarkup: 3.30, optimizedMarkup: 1.50, volume: 22000 },
    { month: 'Aug', avgMarkup: 3.52, optimizedMarkup: 1.48, volume: 19800 },
    { month: 'Sep', avgMarkup: 3.18, optimizedMarkup: 1.35, volume: 26400 },
    { month: 'Oct', avgMarkup: 3.25, optimizedMarkup: 1.25, volume: 31000 },
    { month: 'Nov', avgMarkup: 3.12, optimizedMarkup: 1.15, volume: 12750 },
  ];

  // Theme styling helpers
  const isDark = theme === 'dark';
  const gridColor = isDark ? '#202C2A' : '#E2EAE7';
  const tickColor = isDark ? '#899795' : '#71817D';
  const tooltipBg = isDark ? '#101717' : '#FFFFFF';
  const tooltipBorder = isDark ? '#202C2A' : '#E2EAE7';
  const primaryTeal = isDark ? '#19C3B1' : '#119E91';

  // Savings calculations
  const typicalMarkupCost = annualVolume * 0.0325; // 3.25%
  const optimizedMarkupCost = annualVolume * 0.0125; // 1.25%
  const potentialSavings = typicalMarkupCost - optimizedMarkupCost;

  return (
    <div className="space-y-6">
      <DemoBanner variant="banner" />

      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl sm:text-2xl font-bold tracking-tight text-fx-text">
            FX Intelligence & Conversion Analytics
          </h1>
          <p className="text-xs sm:text-sm text-fx-muted mt-0.5">
            Deep-dive cross-border fee decomposition, spread volatility, and margin capture analysis.
          </p>
        </div>

        {/* Currency Pair & Timeframe selector */}
        <div className="flex flex-wrap items-center gap-2">
          {/* Pair selector */}
          <div className="inline-flex rounded-lg border border-fx-border bg-fx-elevated/80 p-0.5">
            {availablePairs.map((p) => (
              <button
                key={p}
                onClick={() => setSelectedPair(p)}
                className={`px-2.5 py-1 text-xs font-medium rounded-md transition-colors ${
                  selectedPair === p
                    ? 'bg-fx-card text-fx-teal shadow-sm font-semibold'
                    : 'text-fx-muted hover:text-fx-text'
                }`}
              >
                {p}
              </button>
            ))}
          </div>

          {/* Period selector */}
          <div className="inline-flex rounded-lg border border-fx-border bg-fx-elevated/80 p-0.5">
            {periods.map((p) => (
              <button
                key={p}
                onClick={() => setPeriod(p)}
                className={`px-2.5 py-1 text-xs font-medium rounded-md transition-colors ${
                  period === p
                    ? 'bg-fx-teal text-black font-semibold shadow-sm'
                    : 'text-fx-muted hover:text-fx-text'
                }`}
              >
                {p}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Metric Cards Row */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="p-4 rounded-xl border border-fx-border bg-fx-card">
          <span className="text-[11px] font-medium text-fx-muted uppercase tracking-wider block">
            Current Spread Gap
          </span>
          <div className="mt-2 text-2xl font-bold font-mono text-rose-400">
            3.25%
          </div>
          <span className="text-[11px] text-fx-muted mt-1 block">
            ~₹2.81 per USD converted
          </span>
        </div>

        <div className="p-4 rounded-xl border border-fx-border bg-fx-card">
          <span className="text-[11px] font-medium text-fx-muted uppercase tracking-wider block">
            30-Day Rate Volatility
          </span>
          <div className="mt-2 text-2xl font-bold font-mono text-fx-teal">
            0.34%
          </div>
          <span className="text-[11px] text-emerald-400 mt-1 block">
            Low volatility regime
          </span>
        </div>

        <div className="p-4 rounded-xl border border-fx-border bg-fx-card">
          <span className="text-[11px] font-medium text-fx-muted uppercase tracking-wider block">
            Avg Daily Trading Range
          </span>
          <div className="mt-2 text-2xl font-bold font-mono text-fx-text">
            ±0.28 INR
          </div>
          <span className="text-[11px] text-fx-muted mt-1 block">
            Peak activity: 08:00 – 12:00 UTC
          </span>
        </div>

        <div className="p-4 rounded-xl border border-teal-500/30 bg-teal-500/5">
          <span className="text-[11px] font-medium text-fx-teal uppercase tracking-wider block">
            Annual Capture Potential
          </span>
          <div className="mt-2 text-2xl font-bold font-mono text-emerald-400">
            ${formatNumber(potentialSavings, 0)}
          </div>
          <span className="text-[11px] text-fx-muted mt-1 block">
            Based on ${annualVolume.toLocaleString()} annual vol
          </span>
        </div>
      </div>

      {/* Main Historical Chart: Reference Rate vs PayPal Quoted Rate Spread Band */}
      <div className="p-5 rounded-xl border border-fx-border bg-fx-card shadow-subtle">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-4 border-b border-fx-border/60 gap-2">
          <div>
            <h3 className="text-sm font-semibold text-fx-text">
              Reference Rate vs Provider Quote Spread Corridor ({selectedPair})
            </h3>
            <p className="text-xs text-fx-muted mt-0.5">
              The gap between the top line (Mid-market fair value) and bottom line (PayPal settlement) represents margin extracted.
            </p>
          </div>
          <div className="flex items-center space-x-4 text-xs font-mono">
            <div className="flex items-center space-x-1.5">
              <span className="w-2.5 h-2.5 rounded-full bg-fx-teal" />
              <span>Mid-Market (Interbank)</span>
            </div>
            <div className="flex items-center space-x-1.5">
              <span className="w-2.5 h-2.5 rounded-full bg-rose-400" />
              <span>PayPal Quote (Simulated)</span>
            </div>
          </div>
        </div>

        <div className="h-80 w-full mt-4">
          <ResponsiveContainer width="100%" height="100%">
            <ComposedChart data={rateHistory} margin={{ top: 10, right: 10, left: -10, bottom: 0 }}>
              <defs>
                <linearGradient id="spreadArea" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#F16B70" stopOpacity={0.15} />
                  <stop offset="95%" stopColor="#F16B70" stopOpacity={0.02} />
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke={gridColor} vertical={false} />
              <XAxis dataKey="date" stroke={tickColor} fontSize={11} tickLine={false} />
              <YAxis
                stroke={tickColor}
                fontSize={11}
                tickLine={false}
                domain={['auto', 'auto']}
                tickFormatter={(v) => v.toFixed(2)}
              />
              <Tooltip
                content={({ active, payload, label }) => {
                  if (active && payload && payload.length) {
                    const pt = payload[0].payload;
                    return (
                      <div
                        style={{ backgroundColor: tooltipBg, borderColor: tooltipBorder }}
                        className="p-3 rounded-lg border shadow-xl text-xs font-mono space-y-1"
                      >
                        <div className="font-semibold text-fx-text border-b border-fx-border/50 pb-1 mb-1">
                          {label} ({selectedPair})
                        </div>
                        <div className="flex justify-between space-x-4 text-fx-teal">
                          <span>Mid-Market:</span>
                          <span className="font-bold">{pt.midMarket}</span>
                        </div>
                        <div className="flex justify-between space-x-4 text-fx-text">
                          <span>Provider Quote:</span>
                          <span>{pt.provider}</span>
                        </div>
                        <div className="flex justify-between space-x-4 text-rose-400 pt-1 border-t border-fx-border/40 font-semibold">
                          <span>Spread Gap:</span>
                          <span>{pt.spread} ({pt.markupPercent}%)</span>
                        </div>
                      </div>
                    );
                  }
                  return null;
                }}
              />
              <Line
                type="monotone"
                dataKey="midMarket"
                stroke={primaryTeal}
                strokeWidth={2}
                dot={false}
              />
              <Line
                type="monotone"
                dataKey="provider"
                stroke="#F16B70"
                strokeWidth={1.5}
                strokeDasharray="4 2"
                dot={false}
              />
            </ComposedChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Grid: FX Markup Comparison Chart + Conversion Cost Breakdown */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* FX Markup Comparison Chart */}
        <div className="p-5 rounded-xl border border-fx-border bg-fx-card shadow-subtle flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between pb-3 border-b border-fx-border/60">
              <div>
                <h3 className="text-sm font-semibold text-fx-text">
                  Monthly FX Markup Trend (6 Months)
                </h3>
                <p className="text-xs text-fx-muted mt-0.5">
                  Standard PayPal retail markup vs FXPilot optimized batch rate
                </p>
              </div>
              <BarChart3 className="w-4 h-4 text-fx-teal" />
            </div>

            <div className="h-64 w-full mt-4">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={markupMonthlyTrend} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                  <CartesianGrid strokeDasharray="3 3" stroke={gridColor} vertical={false} />
                  <XAxis dataKey="month" stroke={tickColor} fontSize={11} tickLine={false} />
                  <YAxis stroke={tickColor} fontSize={11} tickLine={false} tickFormatter={(v) => `${v}%`} />
                  <Tooltip
                    content={({ active, payload, label }) => {
                      if (active && payload && payload.length) {
                        return (
                          <div
                            style={{ backgroundColor: tooltipBg, borderColor: tooltipBorder }}
                            className="p-3 rounded-lg border shadow-xl text-xs font-mono space-y-1.5"
                          >
                            <span className="font-semibold text-fx-text">{label} Batch Audit</span>
                            <div className="flex justify-between space-x-3 text-rose-400">
                              <span>Standard Markup:</span>
                              <span className="font-bold">{payload[0].value}%</span>
                            </div>
                            <div className="flex justify-between space-x-3 text-fx-teal">
                              <span>FXPilot Route:</span>
                              <span className="font-bold">{payload[1].value}%</span>
                            </div>
                          </div>
                        );
                      }
                      return null;
                    }}
                  />
                  <Bar dataKey="avgMarkup" fill="#F16B70" radius={[4, 4, 0, 0]} name="Standard Retail Markup" />
                  <Bar dataKey="optimizedMarkup" fill={primaryTeal} radius={[4, 4, 0, 0]} name="FXPilot Optimized" />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </div>

          <div className="pt-3 border-t border-fx-border/60 flex items-center justify-between text-xs text-fx-muted">
            <span>Average markup reduced by <strong>2.05%</strong> using scheduled batch conversion.</span>
          </div>
        </div>

        {/* Conversion Cost Breakdown & Anatomical Fee Slices */}
        <div className="p-5 rounded-xl border border-fx-border bg-fx-card shadow-subtle flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between pb-3 border-b border-fx-border/60">
              <div>
                <h3 className="text-sm font-semibold text-fx-text">
                  Where Does Your Money Go? Cross-Border Fee Anatomy
                </h3>
                <p className="text-xs text-fx-muted mt-0.5">
                  Breakdown of typical retail payment gateway costs on $10,000 USD transfer
                </p>
              </div>
              <Layers className="w-4 h-4 text-fx-teal" />
            </div>

            <div className="mt-4 space-y-4">
              {/* Fee slice 1: FX Rate Margin */}
              <div>
                <div className="flex justify-between text-xs mb-1.5">
                  <span className="font-medium text-fx-text flex items-center space-x-1.5">
                    <span className="w-2 h-2 rounded-full bg-rose-400" />
                    <span>Currency Conversion Spread (FX Margin)</span>
                  </span>
                  <span className="font-mono font-bold text-rose-400">3.25% ($325.00)</span>
                </div>
                <div className="w-full bg-fx-elevated h-2.5 rounded-full overflow-hidden">
                  <div className="bg-rose-400 h-full rounded-full" style={{ width: '65%' }} />
                </div>
                <span className="text-[11px] text-fx-muted mt-0.5 block">
                  Embedded markup inside the quoted exchange rate.
                </span>
              </div>

              {/* Fee slice 2: Cross-border surcharge */}
              <div>
                <div className="flex justify-between text-xs mb-1.5">
                  <span className="font-medium text-fx-text flex items-center space-x-1.5">
                    <span className="w-2 h-2 rounded-full bg-amber-400" />
                    <span>Cross-Border International Fee</span>
                  </span>
                  <span className="font-mono font-bold text-amber-400">1.50% ($150.00)</span>
                </div>
                <div className="w-full bg-fx-elevated h-2.5 rounded-full overflow-hidden">
                  <div className="bg-amber-400 h-full rounded-full" style={{ width: '30%' }} />
                </div>
                <span className="text-[11px] text-fx-muted mt-0.5 block">
                  Charged for transactions between different country jurisdictions.
                </span>
              </div>

              {/* Fee slice 3: Fixed processing */}
              <div>
                <div className="flex justify-between text-xs mb-1.5">
                  <span className="font-medium text-fx-text flex items-center space-x-1.5">
                    <span className="w-2 h-2 rounded-full bg-fx-teal" />
                    <span>Fixed Gateway Processing</span>
                  </span>
                  <span className="font-mono font-bold text-fx-teal">0.30% ($30.00)</span>
                </div>
                <div className="w-full bg-fx-elevated h-2.5 rounded-full overflow-hidden">
                  <div className="bg-fx-teal h-full rounded-full" style={{ width: '6%' }} />
                </div>
                <span className="text-[11px] text-fx-muted mt-0.5 block">
                  Standard network interchange and gateway clearance.
                </span>
              </div>
            </div>
          </div>

          <div className="mt-4 p-3 rounded-lg bg-fx-elevated/40 border border-fx-border text-xs flex items-center justify-between">
            <span className="text-fx-muted">Total friction on $10k:</span>
            <span className="font-bold font-mono text-rose-400 text-sm">$505.00 (5.05%)</span>
          </div>
        </div>
      </div>

      {/* Potential Savings Calculator */}
      <div className="p-6 rounded-2xl border border-fx-border bg-fx-card shadow-subtle">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-4 border-b border-fx-border/60 gap-3">
          <div className="flex items-center space-x-3">
            <div className="p-2.5 rounded-xl bg-teal-500/15 border border-teal-500/30 text-fx-teal">
              <Calculator className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-semibold text-fx-text">
                Annual Potential Savings Calculator
              </h3>
              <p className="text-xs text-fx-muted mt-0.5">
                Simulate your annual margin recovery by transitioning from standard retail quotes to optimized batch conversions
              </p>
            </div>
          </div>

          <div className="text-right">
            <span className="text-[10px] font-mono uppercase tracking-wider text-fx-muted block">
              Estimated Annual Savings
            </span>
            <div className="text-2xl font-bold font-mono text-emerald-400">
              ${formatNumber(potentialSavings, 2)}
            </div>
          </div>
        </div>

        <div className="mt-6 space-y-4">
          <div className="flex items-center justify-between text-xs">
            <span className="text-fx-muted font-medium">Annual Cross-Border Volume:</span>
            <span className="font-mono font-bold text-fx-text text-sm">
              ${annualVolume.toLocaleString()} USD
            </span>
          </div>

          <input
            type="range"
            min="25000"
            max="2000000"
            step="25000"
            value={annualVolume}
            onChange={(e) => setAnnualVolume(Number(e.target.value))}
            className="w-full accent-fx-teal cursor-pointer h-2 bg-fx-elevated rounded-lg"
          />

          <div className="flex justify-between text-[11px] font-mono text-fx-muted">
            <span>$25k</span>
            <span>$500k</span>
            <span>$1M</span>
            <span>$2M</span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 pt-4 border-t border-fx-border/60 text-xs">
            <div className="p-3 rounded-lg border border-fx-border bg-fx-elevated/40">
              <span className="text-fx-muted block text-[11px]">Retail Spread Paid (3.25%):</span>
              <span className="font-mono font-bold text-rose-400 text-sm mt-0.5 block">
                ${formatNumber(typicalMarkupCost, 2)}
              </span>
            </div>
            <div className="p-3 rounded-lg border border-fx-border bg-fx-elevated/40">
              <span className="text-fx-muted block text-[11px]">FXPilot Target Spread (1.25%):</span>
              <span className="font-mono font-bold text-fx-teal text-sm mt-0.5 block">
                ${formatNumber(optimizedMarkupCost, 2)}
              </span>
            </div>
            <div className="p-3 rounded-lg border border-emerald-500/20 bg-emerald-500/5">
              <span className="text-emerald-400 block text-[11px] font-medium">Net Retained Margin:</span>
              <span className="font-mono font-bold text-emerald-400 text-sm mt-0.5 block">
                +${formatNumber(potentialSavings, 2)}
              </span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
